---
slug: "monkeyball"
date: "2021-10-23"
title: "Monkey Ball"
logline: "MonkeyBall is a quick, turn-based, Play-to-Earn, arcade, soccer game offering a AAA-gaming experience."
cta: "https://www.monkeyball.com"
logo: /img/monkeyballgame.png
category: nft,game
status: building
website: https://www.monkeyball.com
twitter: https://twitter.com/monkeyballgame
telegram: https://t.me/monkeyball_game
discord: https://discord.gg/ubhDR2F5Kf
---

Matches are played between two teams, each with 4 Monkeys playing the positions of Scorer, Defender, Midfielder and Goalkeeper. With 6 rounds of play per half, 
the first team to 3 goals wins.

Back at your HQ, boost your Monkeys’ abilities and in-game performance by caring for and training them, as well as increasing their morale.

Stadium owners are rewarded for matches they host, while other players can be spectators and influence the gameplay by rooting for a team and increasing their morale.

When a match ends, the in-game currency token, MonkeyBucks ($MBS), is split between the winning team, the Stadium owner, and the spectators who rooted for the winning team.

Play MonkeyBall in Three Modes:
Player vs Environment: Training mode to increase your Monkey’s overall abilities
Player vs Player: Classic game where each player controls the entire team
Team vs Team: Each team is being played and controlled by multiple players
