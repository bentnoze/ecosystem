---
slug: "meanfinance"
date: "2021-10-15"
title: "Mean Finance"
logline: "A self-custody, permissionless & trustless bank bringing #crypto & #DeFi to everyday banking w/ Mean Protocol. Built on Solana"
cta: "https://www.meanfi.com"
logo: /img/meanfinance.jpg
category: app
status: live
website: https://www.meanfi.com
twitter: https://twitter.com/meanfinance
discord: https://discord.gg/qBKDgm49js
---

A Self-Custody, Permissionless & Trustless Bank.
MeanFi brings Crypto and DeFi to everyday banking.
