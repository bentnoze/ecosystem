---
slug: "parrot"
date: "2021-03-22"
title: "Parrot"
logline: "Parrot is a liquidity Network for Lending & Borrowing on Solana."
cta: https://github.com/defactojob/partyparrot
logo: /img/parrot.svg
category: DeFi
website: https://partyparrot.finance/vaults/
twitter: https://twitter.com/gopartyparrot
telegram: https://t.me/gopartyparrot
discord: https://discord.com/invite/gopartyparrot
status: live
---

The Parrot Protocol is a DeFi network built on Solana that will include the stablecoin PAI, a non-custodial lending market, and a margin trading vAMM.
