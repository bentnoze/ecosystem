---
slug: "BST"
date: "2021-08-02"
title: "Balisari"
logline: "Balisari is the first project in Solana which aims as a reward token, our token will ditributed for our costumer who using balisari trans service"
cta: "https://www.balisaritrans.site/"
logo: /img/BST.svg
category: app
status: building
---

Balisari is a customer reward token designed to allow BST customers to conveniently pay fees for travel expenses, daily tours, and airport transportation.
