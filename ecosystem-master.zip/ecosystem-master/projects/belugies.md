---
slug: "belugies"
date: "2021-10-17"
title: "Belugies"
logline: "Belugies are the oh-so cutest collection of hand-illustrated, algorithmically generated NFTs available on the Solana Blockchain"
cta: "https://belugies.com/"
logo: /img/belugies.png
category: nft
status: live
website: https://belugies.com/
twitter: https://twitter.com/belugiesNFT
discord: https://discord.com/invite/belugies
---

Belugies are the oh-so cutest collection of hand-illustrated, algorithmically generated NFTs available on the Solana Blockchain.
