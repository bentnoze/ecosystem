---
slug: "soltreez"
date: "2021-10-18"
title: "SolTreez"
logline: "SolTreez are 10,000 unique trees on Solana with a mission to save the planet."
cta: "https://soltreez.com/"
logo: /img/soltreez.png
category: nft
status: building
website: https://soltreez.com/
twitter: https://twitter.com/SolTreez
discord: https://discord.com/invite/soltreez
---

SolTreez are 10,000 unique trees on Solana with a mission to save the planet.
