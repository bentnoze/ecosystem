---
slug: "apatethicgolemclub"
date: "2021-10-10"
title: "Apathetic Golem Club "
logline: "Apathetic Golem Club is 2500 Collectibles NFT on Solana "
cta: "https://apatheticgolem.io/"
logo: /img/golemclub.png
category: nft
status: building
website: https://apatheticgolem.io/
twitter: https://twitter.com/ApatheticGolem
discord: https://discord.com/invite/xQtxrbCqqt
---

Apathetic Golem Club is 2500 Collectibles NFT on Solana.
