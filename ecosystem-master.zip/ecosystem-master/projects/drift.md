---
slug: "drift"
date: "2021-06-29"
title: "Drift Protocol"
logline: "Drift brings on-chain, cross-margined perpetual futures to Solana, making future DEXs the best way to trade."
cta: https://www.drift.trade
logo: /img/drift.jpg
category: DeFi
status: building
website: https://www.drift.trade
twitter: https://twitter.com/DriftProtocol
---

Drift’s goal is to bring a state-of-the-art trader-centric experience from centralized exchanges on-chain. We’re a team of experienced traders and builders from DeFi and traditional finance working together to make this a reality 👾.
