---
slug: "gokiprotocol"
date: "2021-08-28"
title: "GokiProtocol"
logline: "Improving Solana wallet security and usability"
cta: "https://twitter.com/GokiProtocol"
logo: /img/GokiProtocol.png
category: wallet
status: building
website: https://walletkit.goki.so/
twitter: https://twitter.com/GokiProtocol
---

GokiProtocol Improving Solana wallet security and usability
