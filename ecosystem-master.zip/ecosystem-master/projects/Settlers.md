---
slug: "settlers"
date: "2021-10-24"
title: "Settlers of the Metaverse"
logline: "P2E mini-game on solana"
cta: "https://www.solsettlers.com"
logo: /img/Settlers.png
category: nft
status: building
website: https://www.solsettlers.com
twitter: https://twitter.com/JikanStudios
discord: https://discord.com/invite/BTZzAhR9MD
---

P2E mini-game on solana
