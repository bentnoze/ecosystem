---
slug: "kangaroofightclub"
date: "2021-10-22"
title: "Kangaroo Fight Club"
logline: "10,000 unique Kangaroos NFTs for use in a boxing blockchain game"
cta: "https://www.kangaroofightclub.io"
logo: /img/kangaroofightclub.png
category: nft
status: building
website: https://www.kangaroofightclub.io
twitter: https://twitter.com/KangarooGangNFT
discord: https://discord.com/invite/2A4rkESAQg
---

Each Kangaroo is uniquely created and carefully designed by highly experienced artists by overlaying various pre-designed attributes on the base Kangaroo character.

Fully integrated gaming platform with exciting features. PVP gameplay with SOL betting or fight for fun against friends!
