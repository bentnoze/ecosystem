---
slug: "decentology"
date: "2020-04-03"
title: "Decentology"
logline: "Decentology is a platform that simplifies decentralized app creation. Decentology supports the Solana development environment."
cta: "https://www.decentology.com/"
logo: /img/decentology.svg
category: infra
status: live
---

Decentology built DappStarter, a blockchain-agnostic platform for building full-stack, customizable blockchain apps. We've reduced application build time on Solana from weeks to under fifteen minutes.
