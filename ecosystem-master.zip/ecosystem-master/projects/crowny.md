---
slug: "crowny"
date: "2021-05-11"
title: "Crowny"
logline: "Crowny rewards users for engaging with their favorite brands--ensuring brands reach the right target audience--while protecting user privacy."
cta: "https://crowny.io/"
category: app
logo: /img/crowny.svg
status: live
website: https://crowny.io/en/
twitter: https://twitter.com/crownyio/
telegram: https://t.me/crownyio
---

Crowny is a new advertising platform that will allow brands to effectively reach their target demographic. Users will be able to connect with their favorite brands through a smartphone application, without the risk of privacy breaches.
