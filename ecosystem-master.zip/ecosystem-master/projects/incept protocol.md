---
slug: "incept protocol"
date: "2021-10-15"
title: "Incept Protocol"
logline: "The most user-friendly synthetic asset DEX on Solana"
cta: "https://www.incept.so"
logo: /img/incept_protocol.jpg
category: dex
status: building
website: https://www.incept.so
twitter: https://twitter.com/incept_protocol
telegram: https://t.me/InceptProtocol
discord: https://discord.gg/9SzpnQNPcT
---

Incept protocol enables creation of synthetic assets that captures the real-time price movement of the global assets without the need of collateralized assets.
The protocol is decentralized and community governed.
