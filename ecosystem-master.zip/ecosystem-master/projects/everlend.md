---
slug: "everlend"
title: "Everlend"
date: 2021-07-25
logline: "Everlend is a decentralized, cross-chain lending protocol with yield farming and liquid staking powered by Solana. Built by AtticLab and Everstake."
category: defi
logo: /img/everlend.svg
cta: "https://everlend.finance/"
status: live
website: https://everlend.finance/
twitter: https://twitter.com/EverlendFinance
telegram: https://t.me/joinchat/Znd69xFkYK45NTAy
discord: https://discord.com/invite/wwqnJYQGxM
---

Everlend is a decentralized, cross-chain lending protocol with yield farming and liquid staking powered by Solana. Built by AtticLab and Everstake.
