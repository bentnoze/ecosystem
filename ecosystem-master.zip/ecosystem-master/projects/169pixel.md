---
slug: "169pix3l"
date: "2021-10-03"
title: "196 Pixel"
logline: "169 Pixel Gang is an adult animated gangster sitcom 100% funded by fans."
cta: "https://169pixel.com/"
logo: /img/169pixel.png
category: nft, gaming
status: live
website: https://169pixel.com/
twitter: https://twitter.com/169pixel
discord: https://discord.com/invite/169pixel
---

169 Pixel Gang is an adult animated gangster sitcom 100% funded by fans.
It follows the small time crook Charlie, and his gang of misfts as they try and rise to the top of organised crime in the city.
Holders of Season 1 NFTs will get daily token drops they will be able to use to buy items from the show shop like – tickets to meet the writers, live screenings, merch and more.
