---
slug: "cryptoknight"
date: "2021-10-10"
title: "CryptoKnights"
logline: "CryptoKnights are 9,999 Unique Knights Powered by Solana."
cta: "https://twitter.com/CryptoKnightSOL"
logo: /img/cryptoknight.png
category: nft
status: building
twitter: https://twitter.com/CryptoKnightSOL
discord: https://discord.com/invite/TMmfJwDsKf
---

CryptoKnights are 9,999 Unique Knights Powered by Solana.
