---
slug: "alpharonins"
date: "2021-10-24"
title: "ALPHA:RONINS"
logline: "8888 badass RONINS on Solana"
cta: "https://alpharonins.app"
logo: /img/ALPHA_RONINS.png
category: nft
status: building
website: https://alpharonins.app
twitter: https://twitter.com/ALPHA_RONINS
discord: https://discord.gg/alpharonins
---

RONINS are the first edition of 8888 mercenaries within the ALPHA series. A collection of uniquely badass RONINS on the SOLANA blockchain. 
RONINS are made with over 160 unique traits and attributes of varying rarity.
