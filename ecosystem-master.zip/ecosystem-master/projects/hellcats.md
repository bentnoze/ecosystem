---
slug: "hellcats"
date: "2021-10-17"
title: "HELLCATS"
logline: "HELLCATS are uniquely generated digital collectibles living in harmony on Solana Blockchain"
cta: "https://hellcats.io/"
logo: /img/hellcats.png
category: nft
status: building
website: https://hellcats.io/
twitter: https://twitter.com/hellyeahellcats
discord: https://discord.com/invite/pZQrrCPpdG
---

Hellcats features 8,888 hand-drawn wildcat avatars, each with a unique set of generated traits. Your minted Hellcat is your ticket to the Hellcats world.
