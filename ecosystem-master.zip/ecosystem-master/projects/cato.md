---
slug: "cato"
title: "CATO"
date: 2021-06-22
logline: "CATO is a Serum-based DEX and Solana's first CAT MEME token."
cta: "https://twitter.com/SolanaCATO"
category: dex, app
logo: /img/cato.png
status: Live
---

CATO is one of Solana's first CAT MEME coins with a Serum-based DEX modified to provide maximum user friendly UI.
https://catodex.com/
