---
slug: "solrazr"
title: "SolRazr"
date: "2021-05-28"
logline: "Helping projects raise capital and build fast on Solana."
cta: https://twitter.com/Solrazr_App
category: investmentfund
logo: /img/solrazr.svg
status: live
---

SolRazr is building the launchpad on Solana and supports SPL tokens. We also leverage NFTs for token allocations.
