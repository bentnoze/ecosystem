---
slug: "mathwallet"
date: "2020-04-03"
title: "Math Wallet"
logline: "MathWallet is a multi-chain wallet that supports 60+ blockchains including BTC, ETH, Polkadot, Filecoin, Solana, BinanceChain, etc. and spans more than 1.2 million users. MathWallet app is available for iOS and Android users. It can be used to send and receive SOL tokens."
cta: "https://mathwallet.org"
category: wallet, SPL
logo: /img/math.svg
website: https://mathwallet.org
twitter: https://twitter.com/Mathwallet
telegram: https://t.me/mathwallet
discord: https://discord.com/invite/gXSfnk5eP5
status: live
---

MATH is a multi-chain and cross-chain blockchain assets hub. Products include: MathWallet (supporting 60+ blockchains including BTC, ETH, Polkadot, Filecoin, Solana, BinanceChain, etc. and 1.2 million users), MATH VPoS Pool, MathDAppStore, MathStaking, MathCustody, MathNFT, MathChain, MathHub, MathDEX, MathID, MathPay etc. Our investors includes Fenbushi Capital, Alameda Research, Binance Labs, FundamentalLabs, Multicoin Capital, NGC Ventures. Download the App from Apple Store or Google Play Store to interact with the Solana network on your mobile device. For more information, visit mathwallet.org for more information.
