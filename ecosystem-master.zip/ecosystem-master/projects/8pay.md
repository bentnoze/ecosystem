---
slug: "8pay"
date: "2021-09-22"
title: "8Pay"
logline: "8Pay is a DeFi platform for automatic trustless crypto payments."
cta: "https://8pay.network/"
logo: /img/8pay.svg
category: app, defi
status: building
website: https://8pay.network
twitter: https://twitter.com/8Pay_network
telegram: https://t.me/official_8pay
---

8Pay is a DeFi platform for automatic, trustless crypto payments. 8Pay enables single, recurring, and on-demand payments in their app experience.
