---
slug: "dino"
date: "2021-05-24"
title: "Dino"
logline: "DINO is an experiment around community creation and delivering products that aim to bring fun and awareness to the Solana ecosystem."
cta: "https://www.solanadino.com/"
logo: /img/dino.svg
category: nft, app, game, dex
status: building
website: https://www.solanadino.com/
twitter: https://twitter.com/SolanaDINO
discord: https://discord.gg/BuRMWvRFPm
---

Dino is the ultimate key to enter the Dinoverse. It is issued as a fungible token which allows for the minting of Dino NFTs through a process which creates, incubates, and hatches eggs. The Dino NFT is intended to have a game dynamic to it whereby the NFT’s are characters in a game, and provide additional capability within a game.
