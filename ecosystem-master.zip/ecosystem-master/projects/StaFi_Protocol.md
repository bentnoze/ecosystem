---
slug: "staFiprotocol"
date: "2021-10-15"
title: "StaFi Protocol"
logline: "Liquid Staking Solution for All #PoS Chains. Building synthetic, reward-bearing and tradable rToken."
cta: "https://www.stafi.io"
logo: /img/StaFi_Protocol.jpg
category: app
status: live
website: https://www.stafi.io
twitter: https://twitter.com/StaFi_Protocol
telegram: https://t.me/stafi_protocol
---

Liquid Staking Solution for All #PoS Chains. Building synthetic, reward-bearing and tradable rToken
