---
slug: "BancambiosDeFi"
date: "2021-09-09"
title: "Bancambios DeFi"
logline: "Bancambios is an impact-driven DeFi Ecosystem automatically contributing to projects protecting the Biodiversity of the Planet."
cta: "https://bancambios.exchange"
logo: /img/bancambios.svg
category: defi, dex, tools, wallet, governance
status: building
---

Bancambios is an impact-driven DeFi Ecosystem automatically contributing to projects protecting the Biodiversity of the Planet.
