---
slug: "cryptokickers"
date: "2021-03-01"
title: "Crypto Kickers"
logline: "Crypto Kickers are custom NFT sneakers."
cta: "https://www.cryptokickers.com"
logo: /img/cryptokickers.svg
category: metaplex, nft
status: live
website: www.cryptokickers.com
twitter: https://twitter.com/cryptokickers
discord: https://discord.com/invite/vmXvKcx2QQ
---

Create, customize, and mint your own NFT sneakers directly on the Solana blockchain.
