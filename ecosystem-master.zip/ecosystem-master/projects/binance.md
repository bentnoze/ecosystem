---
slug: "binance"
date: "2020-04-03"
title: "Binance"
logline: "Binance listed SOL in April of 2020."
cta: "https://binance.com/en"
logo: /img/binance.svg
category: exchange
status: live
twitter: https://twitter.com/binance
---

Binance listed SOL in April of 2020. Since our listing, multiple trading pairs have been added, and margin trading is available for eligible users.
