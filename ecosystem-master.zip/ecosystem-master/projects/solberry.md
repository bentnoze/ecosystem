---
slug: "SolBerry"
date: "2021-09-29"
title: "SOLBERRY"
logline: "SOLBERRY is a DEX project which is built on Serum"
cta: "https://solberry.tech/"
logo: /img/solberry.png
category: defi
status: live
website: https://solberry.tech/
twitter: https://twitter.com/berrysol
telegram: https://t.me/Solberry_tg
---

SOLBERRY is a DEX project which is built on Solana and fork of SERUM DEX.
Our aim is to build a SuperFast Dex for Solana Blockchain Community members .
We aim to implement Swaps and Leverage trading on our dex too.
SolBerry project also working on NFT Token.
