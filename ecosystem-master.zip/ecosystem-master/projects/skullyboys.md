---
slug: "skullyboys"
date: "2021-09-30"
title: "Skully Boys"
logline: "Skully Boys is the NFTs project by the artist Jaleye"
cta: "https://skullyboys.io/"
logo: /img/skully.png
category: nft
status: live
website: https://skullyboys.io/
twitter: https://twitter.com/SkullyBoysBC?s=09
discord: https://discord.gg/w75NRgMc7V
---

Skully Boys is the NFTs project by the artist Jaleye
