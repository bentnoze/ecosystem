---
slug: "Abstratica"
date: "2021-07-01"
title: "Abstratica"
logline: "Deep Neutral Networks generative arts."
cta: "https://abstratica.holaplex.com/#/"
logo: /img/abstratica.svg
category: metaplex, nft
website: https://www.abstratica.art/
twitter: https://twitter.com/abstraticanft
discord: https://discord.com/invite/Jhc8hg7Fy3
status: live
---

Abstratica is Deep Neural Networks generative art.
