---
slug: "solsisters"
date: "2021-10-17"
title: "SolSisters"
logline: "A unique, allegorical collection of artwork coming to the solana blockchain, representing a new era of sustainability in NFTs"
cta: "https://www.solsisters.xyz"
logo: /img/solsister.png
category: nft
status: live
website: https://www.solsisters.xyz
twitter: https://twitter.com/RealSolSisters
discord: http://discord.gg/solsisters
---

representing a new era of sustainability within the NFT world; SolSisters are mythical characters of the future,
returning to Earth in hopes to save Mother Nature and all her creations.
