---
slug: "jupiteraggregator"
date: "2021-10-24"
title: "Jupiter Aggregator"
logline: "The best swap aggregator on Solana. Built for smart traders who like money."
cta: "https://twitter.com/JupiterExchange"
logo: /img/jupiteraggregator.jpg
category: defi
status: live
website: https://jup.ag
twitter: https://twitter.com/JupiterExchange
discord: https://discord.com/invite/WBSDXjYGR3
---

Jupiter Aggregator goal is to provide the best rates by routing across all major liquidity markets, 
while giving users and developers the best swapping experience in all of DeFi.
