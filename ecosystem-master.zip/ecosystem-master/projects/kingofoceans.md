---
slug: "kingofoceans"
date: "2021-09-14"
title: "King Of Oceans"
logline: "King Of Oceans is an NFT-powered RPG game built natively on the Solana blockchain."
cta: "https://kingofoceans.com/"
logo: /img/kingofoceans.svg
category: nft,dapp
status: building
website: https://kingofoceans.com/
twitter: https://twitter.com/KingOfOceansNFT
discord: https://discord.gg/mhDtBMXEyf
---

King Of Oceans is an NFT-powered RPG game built natively on the Solana blockchain. Gamers will battle and win NFT characters and NFT gears that can be converted to SOL at the marketplace.
