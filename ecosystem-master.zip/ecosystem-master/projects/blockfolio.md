---
slug: "ftx"
date: "2020-04-03"
title: "FTX (formerly Blockfolio)"
logline: "The world’s most popular Bitcoin & cryptocurrency portfolio tracker. Supports the buying and trading of USDC-SPL."
cta: "https://blockfolio.com/coin/SOL"
logo: /img/blockfolio.svg
category: exchange, SPL, wallet, explorer
status: live
twitter: https://twitter.com/FTX_Official
---

FTX (formerly Blockfolio) is the world’s most popular Bitcoin & cryptocurrency portfolio tracker. Supports the buying and trading of USDC-SPL.
