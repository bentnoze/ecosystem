---
slug: "meowplex"
date: "2021-05-01"
title: "Meowplex"
logline: "NFT Coin for the Coolest Cat online community. Built on Solana."
cta: "https://meowplex.holaplex.com/#/"
logo: /img/Meowplex.svg
category: metaplex, nft
status: live
website: https://meowplex.holaplex.com/#/
twitter: https://twitter.com/solcat777
discord: https://discord.com/invite/qax5xrbysj
---

Meowplex is an NFT coin for the Coolest Cat online community. Built on Solana's fast, eco-friendly blockchain.
