---
slug: "salty"
date: "2020-04-03"
title: "Salty.ai"
logline: "Salty is a validator explorer that aggregates data across Mainnet Beta, Tour de SOL, and Wormhole."
cta: "https://salty.ai/"
logo: /img/salty.svg
category: explorer
status: live
---

Salty Stats is a comprehensive validator explorer that aggregates multiple data points across Mainnet Beta, Tour de SOL, and Wormhole.
