---
slug: "seic"
date: "2021-10-08"
title: "Serious Eagle Investors Club"
logline: "SEIC is the exclusive investment club with Serious Eagle NFT owners in pursuit of environmental, social and governance (ESG)-themed."
cta: "https://seriouseagleinvestors.club"
logo: /img/seic.svg
category: nft, fund, investmentfund, governance
status: live
website: https://seriouseagleinvestors.club
twitter: https://twitter.com/SeriousEagleIC
discord: https://discord.gg/EdZRgVUYrT
---

SEIC is the exclusive investment club with Serious Eagle NFT owners in pursuit of environmental, social and governance (ESG)-themed.
