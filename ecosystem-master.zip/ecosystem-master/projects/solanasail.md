---
slug: "solanasail"
title: "SolanaSail"
date: 2021-06-22
logline: "SAIL is the first randomly distributed community token. gSAIL is the governance token of the SolanaSail ecosystem, but SAIL will be the main utility token of a new ecosystem built on Solana. SAIL and gSAIL will both be used on the future SolanaSail ecosystem platform, which will offer governance, vaults, DeFi, NFT, and PlaytoEarn games."
cta: "https://twitter.com/SolanaSail"
category: defi, app, spl, tools
logo: /img/solanasail.svg
status: Building
---

SolanaSail's governance platform will provide to all SPL tokens and projects the ability to create and vote for proposals.
