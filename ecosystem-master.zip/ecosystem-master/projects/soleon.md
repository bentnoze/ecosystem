---
slug: "soleon"
date: "2021-04-12"
title: "Soleon"
logline: "Soleon is a fully-featured decentralized derivatives exchange with trustless cross-chain trading built on the Solana blockchain. Powered by @ProjectSerum."
cta: "https://soleon.io/"
logo: /img/soleon.svg
category: dex
website: https://soleon.io/
twitter: https://twitter.com/soleon_io
status: live
---

A fully-featured decentralized derivatives exchange with trustless cross-chain trading built on the @Solana blockchain. Powered by @ProjectSerum.
