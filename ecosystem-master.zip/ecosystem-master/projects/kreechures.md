---
slug: "kreechures"
date: "2021-03-22"
title: "Kreechures"
logline: "Kreechures is Solana's first crypto-collectible NFT RPG. Generation-0 Kreechure arrivals began in March 2021 and will continue until we hit our limit. Generative NFTs that are yours to level up, collect, trade, or sell"
cta: https://www.kreechures.com/
logo: /img/kreechures.svg
category: nft
status: building
---

Kreechures, aka crypto-collectible non-fungible tokens (NFTs) stored on the Solana (SOL) blockchain, are one of a kind and yours to level up, collect, trade or sell.
