---
slug: "solanaproject"
date: "2020-04-03"
title: "Solana Project"
logline: "Solana Project is an educational site providing information on projects building in the Solana ecosystem."
cta: "https://solanaproject.com/"
logo: /img/solanaproject.svg
category: explorer
status: live
---

Solana Project is an educational site providing information on projects building in the Solana ecosystem.
