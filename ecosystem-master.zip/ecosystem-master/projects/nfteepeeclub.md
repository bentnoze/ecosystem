---
slug: "nfteepeeclub"
date: "2021-10-19"
title: "NFTeePee"
logline: "NFT collectible built on Sol! 7777 available rolls for club."
cta: "https://nfteepee.club/mint"
logo: /img/teepee.png
category: nft
status: live
website: https://nfteepee.club/mint
twitter: https://twitter.com/NFTeePeeClub
discord: https://discord.com/invite/QAuZWqGHW4
---

NFT collectible built on Sol! 7777 available rolls for club.
