---
slug: "solanbananas"
date: "2021-10-03"
title: "Solanabananas"
logline: "Solanabanas is 1500 Fruity, Unique, Algorithmically generated Bananas. Stored with proof of ownership on the Solana blockchain."
cta: "https://solanabananas.com/"
logo: /img/solanabananas.png
category: nft
status: live
website: https://solanabananas.com/
twitter: https://twitter.com/solanabananas
discord: https://discord.com/invite/VHcfR85T6y
---

Solanabanas is 1500 Fruity, Unique, Algorithmically generated Bananas. Stored with proof of ownership on the Solana blockchain.
