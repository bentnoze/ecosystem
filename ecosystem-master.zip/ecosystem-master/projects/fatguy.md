---
slug: "FatGuy"
date: "2020-10-20"
title: "FatGuy"
logline: "3225 Unique NFTs.The metaverse is endless, will you able to find me?"
cta: "https://fatguy.cool"
logo: /img/fatguy.png
category: nft, game
status: building
website: https://fatguy.cool/
twitter: https://twitter.com/fatguynft
discord: https://discord.gg/fatguy
---

3225 Unique NFTs.The metaverse is endless, will you able to find me?
