---
slug: "bitspawnprotocol"
title: "Bitspawn Protocol"
date: "2021-05-28"
logline: "Bitspawn is a layer-2 gaming blockchain protocol built to support 2+ billion gamers by building easily accessible monetization streams."
cta: https://twitter.com/BitspawnGG
category: app
logo: /img/bitspawnprotocol.svg
status: building
website: https://bitspawn.io
twitter: https://twitter.com/BitspawnGG
telegram: https://t.me/bitspawngg
discord: https://discord.com/invite/bitspawn
---

Bitspawn is an open-source gaming protocol creating a global decentralized gaming economy and enabling over 2 billion gamers around the world to gain access to new streams of income outside the traditional areas of streaming and content.
