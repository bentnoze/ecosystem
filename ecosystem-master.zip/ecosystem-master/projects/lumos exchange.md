---
slug: "lumosexchange"
title: "Lumos Exchange"
date: "2021-05-28"
logline: "Lumos is developing the first non-custodial, peer-to-peer exchange for Solana."
cta: "https://www.lumos.exchange/"
category: dex
logo: /img/lumosexchange.svg
status: building
website: https://www.lumos.exchange/
twitter: https://twitter.com/LumosExchange
discord: https://discord.gg/aNDpkWp9wG
---

Lumos Exchange is currently the only P2P exchange with a focus on Solana. Our solution will integrate with SOL by providing buy/sell features in 186 countries and utilizing more than 100+ payment methods.

Every project that currently exists on Solana could be accessible by purchasing SOL via Lumos Exchange.
