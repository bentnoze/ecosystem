---
slug: "acumen"
date: "2021-06-29"
title: "Acumen Protocol"
logline: "Acumen is a Defi lending and borrowing protocol built natively on the Solana blockchain."
cta: "https://acumen.network/"
logo: /img/acumen.svg
category: app
status: live
---

Acumen is a Defi lending and borrowing protocol built natively on the Solana blockchain. Acumen empowers seamless yield earning on SPL Tokens through the use of algorithmically set interest rates which are a function of supply and demand.
