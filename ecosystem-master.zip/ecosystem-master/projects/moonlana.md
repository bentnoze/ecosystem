---
slug: "moonlana"
title: "Moonlana"
date: 2021-06-22
logline: "Solana Tipbot, NFTs, DEX, and Memes."
cta: "https://twitter.com/xmoonlana"
category: dex, tools
logo: /img/moonlana.svg
status: Live
---

Moonlana created an on-chain tip bot that can currently be used on Discord.
