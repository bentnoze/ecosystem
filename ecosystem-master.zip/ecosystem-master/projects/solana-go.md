---
slug: "solana-go"
date: "2021-07-29"
title: "solana-go"
logline: "Solana SDK for the Go programming language."
cta: "https://github.com/gagliardetto/solana-go"
logo: /img/golang.svg
category: sdk
status: live
---

solana-go is an SDK library for the Go programming language for interacting with the Solana blockchain.
Build and integrate your Go applications with Solana.
