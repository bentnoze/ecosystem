---
slug: "lobstershack"
date: "2021-03-01"
title: "Lobster Shack"
logline: "The Crypto Langoustine."
cta: "https://lobstershack.holaplex.com/#/"
logo: /img/Lobster shack.svg
category: metaplex, nft
status: live
website: https://lobstershack.holaplex.com/#/
twitter: https://twitter.com/nephr0ps
---

Lobster shack is a crypto langoustine and NFT artist.
