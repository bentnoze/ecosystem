---
slug: "starbots"
date: "2021-10-25"
title: "Star Bots"
logline: "Starbots is the first-ever Dog robot battle NFT game on the Solana Network. "
cta: "https://starbots.net"
logo: /img/starbots.png
category: nft
status: building
website: https://starbots.net/
twitter: https://twitter.com/Starbots_game
telegram: https://t.me/starbotsofficial
discord: https://discord.gg/arCt64m2ms
---

Starbots is the first-ever robot battle NFT game where players gain GEAR tokens through strategically assembling their own robots,
winning battles, completing missions, and conquering new lands.
