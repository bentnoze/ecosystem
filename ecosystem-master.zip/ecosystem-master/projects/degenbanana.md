---
slug: "degenbanana"
date: "2021-05-28"
title: "degenbanana"
logline: "degenbanana is leveraged memeing on the Solana blockchain."
twitter: https://twitter.com/degenbanana
cta: "https://degen.finance"
logo: /img/degenbanana.svg
category: defi
status: live
---

degenbanana is building a protocol to facilitate leveraged yield farming within the Solana ecosystem, and, later, in a chain agnostic way.
