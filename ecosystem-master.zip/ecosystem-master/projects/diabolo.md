---
slug: "diabolo"
date: "2021-06-15"
title: "Diabolo"
logline: "Diabolo provides a complete ecosystem centered around social trading, including CeFi, DeFi and Staking services."
cta: "https://twitter.com/diabolotrading"
logo: /img/diabolo.svg
category: defi, dex
status: building
---

Diabolo is a social trading ecosystem providing a complete ecosystem centered around social trading, including CeFi, DeFi and Staking services.
