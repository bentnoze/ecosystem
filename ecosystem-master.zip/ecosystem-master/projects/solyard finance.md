---
slug: "solyardfinance"
title: "Solyard Finance"
date: 2021-06-22
logline: "Solafarm Finance is a Yield Farming Aggregator Optimizer protocol on Solana."
cta: "https://solyard.finance/"
category: amm, defi, dex
logo: /img/solyardfinance.svg
status: Live
website: https://solyard.finance/
twitter: https://twitter.com/SolyardFinance
discord: https://t.co/02RyvPFHxw?amp=1
telegram: https://t.co/iqV3V2POS5?amp=1
---

SolYard is a new Yield Farming Aggregator for the Solana Ecosystem. SolYard provides yield enhancement strategies for your Solana crypto assets.
