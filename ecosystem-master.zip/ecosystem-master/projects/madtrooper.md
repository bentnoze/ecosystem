---
slug: "madtrooper"
date: "2021-10-09"
title: "Mad Trooper"
logline: "Mad Trooper NFT are on the Solana blockchain, and joining the grand battle that will decide the very fate of the world. Each MadTrooper is completely unique and has been algorithmically generated to possess special attributes and traits. "
cta: "https://madtrooper.com/"
logo: /img/madtrooper.png
category: nft
status: live
website: https://madtrooper.com/
twitter: https://twitter.com/TheMadTrooper
discord: https://discord.com/invite/N7tWFsdPUJ
---

Mad Trooper NFT are on the Solana blockchain, and joining the grand battle that will decide the very fate of the world. Each MadTrooper is completely unique and has been algorithmically generated to possess special attributes and traits.
