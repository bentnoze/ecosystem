---
slug: "huobi"
date: "2020-04-03"
title: "Huobi"
logline: "Huobi has listed the SOL token, and maintains three trading pairs."
cta: "https://www.huobi.pr/en-us/exchange/sol_btc/"
logo: /img/huobi.svg
category: exchange
status: live
---

Huobi provides hundreds of tokens & futures trading pairs to enable traders to optimize their strategies in a seamless trading interface.
