---
slug: "korbit"
date: "2021-06-08"
title: "Korbit"
logline: "Korbit, Korea’s first crypto exchange, listed SOL on June 8th, 2021, making it the first listing in KRW market"
cta: "https://exchange.korbit.co.kr/markets/?market=sol-krw"
logo: /img/korbit.svg
category: exchange
status: live
---

Korbit is Korea’s first crypto exchange. Established in 2013.
