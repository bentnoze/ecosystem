---
slug: "randomaccessmemories"
date: "2021-06-01"
title: "Random Access Memories"
logline: "Retrofuture inspired collectibles from the block."
cta: "https://ram.so/"
logo: /img/Ram.svg
category: metaplex, nft
status: live
website: https://ram.so/
twitter: https://twitter.com/RAM_NFT
discord: https://discord.com/invite/fZP4g4BYdD
---

Random Access Memories is designing retrofuture inspired collectibles from the block.
