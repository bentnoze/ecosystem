---
slug: "almond"
date: "2021-10-24"
title: "Almond"
logline: "Fair and Nutritious. Powering yield farming and core DeFi primitives on Solana"
cta: "https://twitter.com/almond_so"
logo: /img/Almond.jpg
category: defi
status: live
website: https://almond.so/
twitter: https://twitter.com/almond_so
discord: https://discord.gg/Cj78CfDcSu
---

Fair and Nutritious. Powering yield farming and core DeFi primitives on Solana
