---
slug: "quarry protocol"
date: "2021-10-15"
title: "Quarry Protocol"
logline: "Quarry is an open protocol for launching liquidity mining programs on Solana"
cta: "https://twitter.com/QuarryProtocol"
logo: /img/QuarryProtocol.png
category: app
status: building
twitter: https://twitter.com/QuarryProtocol
---

Quarry is an open protocol for launching liquidity mining programs on Solana
