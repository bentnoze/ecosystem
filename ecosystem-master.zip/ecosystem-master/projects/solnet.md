---
slug: "solnet"
date: "2021-07-29"
title: "Solnet"
logline: "Solnet is Solana's .NET SDK to integrate with the .NET ecosystem."
cta: "https://github.com/bmresearch/Solnet"
logo: /img/dotnet.svg
category: sdk
status: live
---

Solnet is Solana's .NET SDK to integrate with the .NET ecosystem.
Whether you are developing for the web or desktop applications, Solnet can be used within .NET applications to integrate with Solana.
