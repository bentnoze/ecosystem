---
slug: "catchking"
date: "2021-10-17"
title: "CatchKing"
logline: "The CatchKing Explorers are 5555 randomly generated NFTs."
cta: "https://www.catchking.io"
logo: /img/catchking.png
category: nft, game
status: live
website: https://www.catchking.io
twitter: https://twitter.com/catch_king
discord: https://discord.gg/Dde5e8fEzt
---

CatchKing is an in-development top-down, roguelike, collect-a-thon RPG feautring crisp pixel graphics that has inspired our new line of NFTs. The CatchKing Explorers are 5555 randomly generated NFTs coming soon to the Solana Blockchain.