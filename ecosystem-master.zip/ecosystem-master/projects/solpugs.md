---
slug: "solpugs"
date: "2021-10-09"
title: "Sol Pugs"
logline: "2205 Uniquely generated pugs, with over 70+ different attributes exclusively made for solana's blockchain & our upcoming NFT Gaming Marketplace!"
cta: "https://solpugs.io/"
logo: /img/solpugs.png
category: nft, game
status: live
website: https://solpugs.io/
twitter: https://twitter.com/solpugsnft
discord: https://discord.com/invite/2tq9zG6WtV
---

2205 Uniquely generated pugs, with over 70+ different attributes exclusively made for solana's blockchain & our upcoming NFT Gaming Marketplace!
