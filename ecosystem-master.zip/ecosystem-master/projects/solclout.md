---
slug: "solclout"
title: "Solclout"
date: 2021-07-25
logline: "Social DeFi Platform built on Solana."
category: defi
cta: https://twitter.com/Solclout
logo: /img/solclout.svg
status: live
website: https://solclout.com/
twitter: https://twitter.com/Solclout
telegram: https://t.me/solclout
---

SolClout is envisioning a platform to build a formidable community powered by Solana, a high throughput, scalable public blockchain project. SolClout will allow for cryptocurrency projects and users to create and boot-strap Clout-driven communities geared towards building fast and sustainable social presences.
