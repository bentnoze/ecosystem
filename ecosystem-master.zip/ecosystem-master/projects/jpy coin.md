---
slug: "jpycoin"
title: "JPY Coin"
date: "2021-05-28"
logline: "JPY Coin is a 1:1 JPY-pegged stable coin built on Solana."
cta: "https://jpyc.jp/"
category: stablecoin
logo: /img/jpycoin.svg
status: building
website: https://jpyc.jp/
twitter: https://twitter.com/jpy_coin
---

JPY Coin (JPYC) is aiming to bring Japanese yen from the real world to Solana. With an active team and enthusiastic communities, JPYC ’s presence has been growing very rapidly. In Japan legally, JPYC isn’t a collateral-backed cryptocurrency, but a prepaid stablecoin issued by JPYC Inc. Users who have JPYC can shop using JPYC at the rate of 1 JPYC = 1 JPY. JPYC is also planning to support paying hometown tax using JPYC. JPYC is being traded on some DEX by the communities.
