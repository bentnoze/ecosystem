---
slug: "solyetis"
date: "2021-10-06"
title: "SolYetis"
logline: "8888 Yetis are coming down from the mountains to form the Sol Yetis. 75% of royalties go to holders and minters."
cta: "https://solyetis.io/"
logo: /img/solyetis.png
category: nft
status: live
website: https://solyetis.io/
twitter: https://twitter.com/SolYetis
discord: https://discord.gg/dxZvHtWpbb
---

8888 Yetis are coming down from the mountains to form the Sol Yetis. 75% of royalties go to holders and minters.
