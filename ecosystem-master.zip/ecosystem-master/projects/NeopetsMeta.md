---
slug: "neopetsmeta"
date: "2021-10-15"
title: "NeopetsMeta"
logline: "The Neopets exist as SPL tokens based on the Metaplex NFT standard."
cta: "https://www.neopetsmetacollection.com"
logo: /img/neopetsmeta.png
category: nft
status: building
website: https://www.neopetsmetacollection.com
twitter: https://twitter.com/NeopetsMeta
medium: https://neopetsmetaverse.medium.com
discord: https://discord.com/invite/neopets-metaverse
---

The Neopets Metaverse are a collection of 20,500 uniquely generated, cute and loveable Neopets NFTs living on the Solana Blockchain.
The Neopets exist as SPL tokens based on the Metaplex NFT standard.
