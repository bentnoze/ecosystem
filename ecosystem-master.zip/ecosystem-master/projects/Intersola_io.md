---
slug: "intersola_io"
date: "2021-04-30"
title: "Intersola_io"
logline: "Decentralized fund raising for the Solana ecosystem"
cta: "https://intersola.io"
logo: /img/Intersola_io.jpg
category: defi
status: Live
website: https://intersola.io
twitter: https://twitter.com/Intersola_io
telegram: https://t.co/cLT01YlIid?amp=1
discord: https://discord.com/invite/12A3bcDE1f
---

Launchpad and insights platform for the Solana universe.
