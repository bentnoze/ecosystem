---
slug: "blocto"
date: "2019-07-01"
title: "Blocto"
logline: "Make blockchain simple and accessible for everyone."
cta: "https://blocto.portto.io/en/"
logo: /img/Blocto.svg
category: metaplex, nft
status: live
website: https://blocto.portto.io/en/
twitter: https://twitter.com/bloctoapp
telegram: https://t.me/blocto
discord: https://discord.com/invite/h34kzqf
---

Blockchain technology has disrupted various industries, including finance, medicine, education and entertainment. You can explore this new world hassle-free with the guidance and the friendly user experience provided by Blocto.
You can purchase and utilize thousands of different crypto assets with a unified interface, without understanding the underlying technical differences.
