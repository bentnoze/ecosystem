---
slug: "galacticgecko"
date: "2021-10-03"
title: "Galactic Gecko Space Garage"
logline: "Galactic Gecko Space Garage is an NFT Social Adventure Club featuring 10,000 warrior turned space racing geckos. “Sponsor” a Galactic Gecko by owning its NFT on the Solana Blockchain. "
cta: "https://galacticgeckos.app/"
logo: /img/galacticgecko.png
category: nft, gaming
status: live
website: https://galacticgeckos.app/
twitter: https://twitter.com/galacticgeckosg
discord: https://discord.gg/9pd6fKWdQk
---

Galactic Gecko Space Garage is an NFT Social Adventure Club featuring 10,000 warrior turned space racing geckos. “Sponsor” a Galactic Gecko by owning its NFT on the Solana Blockchain. Doing so will grant you a spot in the most elite, fierce and thrill-seeking club in the universe. Choose your faction (or factions) wisely. It has cosmic consequences..
