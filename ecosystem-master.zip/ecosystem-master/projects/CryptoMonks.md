---
slug: "crypto monks"
date: "2021-07-01"
title: "crypto monks"
logline: "Zen monk NFTs on Solana."
cta: "https://cryptomonks.holaplex.com/"
logo: /img/cryptomonks.svg
category: metaplex, nft
status: live
website: https://cryptomonks.holaplex.com/
twitter: https://twitter.com/cryptomonx
---

CryptoMonks are building Zen monk NFTs on Solana.
