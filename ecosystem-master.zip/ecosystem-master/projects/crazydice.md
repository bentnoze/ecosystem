---
slug: "crazydice"
date: "2021-08-02"
title: "CrazyDice"
logline: "A fair crypto dice game on Solana"
cta: "https://www.crazydice.app/"
logo: /img/crazydice.svg
category: game
status: live
website: https://www.crazydice.app/
telegram: https://t.me/crazydiceofficial
---

CrazyDice is a decentralized game designed on Solana. You can easily play by simply placing Solana.
