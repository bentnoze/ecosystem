---
slug: "amogusnft"
title: "Amogus NFT"
date: 2021-09-22
logline: "10,000 unique Solana Sus sussy made by punks"
category: nft, metaplex
cta: https://amogusnft.com/
logo: /img/amogusnft.png
status: building
website: https://amogusnft.com/
twitter: https://twitter.com/NFT_Amogus
discord: https://discord.gg/nwcJhZuZWX
---

This is a Solana version of Amogus NFT which will have its own unique avatars and legendary tokens.
Amogus NFT is a project based on the legendary meme which makes NFT affordable and closer to the audience.
A special algorithm makes up a unique name for every of 10,000 Amoguses based on the way they look.

We're trying to build an interchain community, where people using different chains can get collections united by one idea.
Our project will also allow to diversify an NFT collection.

We're already working with the audience in Twitter and Discord, holding giveaways and explaining our ideas.
Next step is giving every Sus a voice tag, connected to its name.
A general idea is to allow people to make a global interchain market.
