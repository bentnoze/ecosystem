---
slug: "niftynanas"
date: "2021-10-16"
title: "Nifty Nanas"
logline: "Nifty Nanas is a collection of 8,888 uniquely generated bananas that was built to represent a commitment to supporting the Solana ecosystem. "
cta: "https://www.niftynanas.com/"
logo: /img/niftynanas.png
category: nft
status: live
website: https://www.niftynanas.com/
twitter: https://twitter.com/NiftyNanas
discord: https://discord.com/invite/niftynanas
---

Nifty Nanas is a collection of 8,888 uniquely generated bananas that was built to represent a commitment to supporting the Solana ecosystem.
