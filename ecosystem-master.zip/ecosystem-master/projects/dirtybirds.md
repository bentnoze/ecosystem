---
slug: "dirtbirds"
date: "2021-10-03"
title: "Dirty Birds Fight Club"
logline: "Dirty Birds Fight Clucb are 9090 unique NFTs generated from over 200 traits."
cta: "https://dirtybirdrecords.com/pages/flightclub"
logo: /img/dirtybirds.png
category: nft
status: live
website: https://dirtybirdrecords.com/pages/flightclub
twitter: https://twitter.com/DirtybirdArt
discord: https://discord.gg/flightclub
---

Dirty Birds Fight Clucb are 9090 unique NFTs generated from over 200 traits.
