---
slug: "coinbase"
date: "2021-05-20"
title: "Coinbase"
logline: "Coinbase listed SOL in July of 2021."
cta: "https://www.coinbase.com/price/solana"
logo: /img/coinbase.svg
category: exchange
status: live
twitter: https://twitter.com/coinbase/
---

Coinbase listed SOL in July of 2021. Since our listing, multiple trading pairs have been added and margin trading is available for eligible users.
