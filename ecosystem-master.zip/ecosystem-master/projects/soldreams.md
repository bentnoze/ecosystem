---
slug: "soldreams"
date: "2021-09-08"
title: "SOLdreams"
logline: "NFT dreams dreamed by an neuronal net (artificial intelligence)."
cta: "https://soldreams.com/"
logo: /img/soldreams.png
category: nft, metaplex
status: live
website: https://soldreams.com/
twitter: https://twitter.com/SOLdreamsNFT
discord: https://discord.gg/MY4DbEUrjk
---

SOLdreams are NFT pictures taken from "dreams" dreamed by an neuronal net (artificial intelligence). </br>
Psychedelic, beautiful and sometimes frightening.</br>

SOLdreams are published in collections (EDITIONs) of 25 images each.</br>
They are very rare, there will be only 250 SOLdreams in total!</br>
EDITION ONE starts with 25 beautiful deep dreams

<b>Website</b>: https://soldreams.com </br>
<b>NFT Marketplace</b>: https://nft.soldreams.com </br>
<b>Twitter</b>: https://twitter.com/SOLdreamsNFT </br>
<b>Discord</b>: https://discord.gg/MY4DbEUrjk </br>
