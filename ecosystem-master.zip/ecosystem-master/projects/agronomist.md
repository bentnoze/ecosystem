---
slug: "agronomist"
date: "2021-08-31"
title: "Agronomist"
logline: "Powerful DeFi analytics platform for farming, staking and liqudity pools"
cta: "https://agronomist.tech"
logo: /img/agronomist.png
category: defi, explorer, tools
status: building
---

Agronomist.tech - powerful analytics platform for farming, staking and liqudity pools based on Solana platform. This project provide indicators for farming, analytics about reliability and allow create some notifications for any indicators.

<b>Website</b>: https://agronomist.tech </br>
<b>Twitter</b>: https://twitter.com/AgronomistTech </br>
<b>Discord</b>: https://discord.gg/tR45QftB6K </br>
