---
slug: "Krida Fans"
date: "2021-06-29"
title: "Krida Fans"
logline: "Krida Fans is a next generation fantasy sports and social platform built on the Solana blockchain."
cta: "https://krida.fans"
logo: /img/krida-fans.svg
category: app
status: building
---

Krida Fans is the reimagined Fantasy Sports and Social Platform. It differentiates itself from other blockchain and non-blockchain based platforms in the following ways:

Skill based Scarcity: We have democratized access of the players' cards NFTs to all the participants of the platform. These NFTs will become scarce based on how the participants use them in building their fantasy team for the game.

Multichain Community Reputation: Participants can also discuss and share tips on the discord server for the Krida Fans. Each activity will have points associated with it (negative and positive). Thus creating a unique non-transferrable NFT for each participant which can be used in other blockchains or blockchain-based games.

NFT based Card games: Our players' card NFTs are detail rich in such a way that holders of these NFTs can play card games with their friends. Krida Fans will host card games for top 25 Social Reputation NFT holders with guaranteed prize money.
