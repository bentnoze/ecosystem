---
slug: "apeboard"
date: "2021-05-11"
title: "ApeBoard"
logline: "ApeBoard is a cross-chain DeFi dashboard that supports Solana."
cta: "https://apeboard.finance/"
category: app
logo: /img/apeboard.svg
status: live
twitter: "https://twitter.com/ape_board/"
telegram: "https://t.me/apeboard"
---

ApeBoard is a cross-chain DeFi dashboard that supports the Solana network.

<b>twitter:</b>https://twitter.com/ape_board/
