---
slug: "hollowsoldiers"
date: "2021-10-09"
title: "Hollow Soldiers"
logline: "Hollow Soldiers are two groups of 3333 NFTs that are algorithmically generated, undead, and violent soldiers battling (see Battleground) for the reigns of a post-apocalyptic Earth housed on the Solana Blockchain."
cta: "https://hollowsoldiers.com/"
logo: /img/hollowsoldiers.png
category: nft, game
status: live
website: https://hollowsoldiers.com/
twitter: https://twitter.com/HollowSoldiers
discord: https://discord.com/invite/GkG8gVR6tB
---

Hollow Soldiers are two groups of 3333 NFTs that are algorithmically generated, undead, and violent soldiers battling (see Battleground) for the reigns of a post-apocalyptic Earth housed on the Solana Blockchain.

Each soldier is part of a faction, The Ravagers and The Roamers. Each one is unique and randomly generated with more than 99 traits. The traits will play a part in Generation 2 and an in-browser game which will begin development after launch.
