---
slug: "nonfungiblebees"
date: "2021-10-11"
title: "NON-FUNGIBLE BEES"
logline: "3333 Bees Swarming The Solana Ecosystem."
cta: "https://www.nonfungiblebees.io/"
logo: /img/nonfungiblebees.png
category: metaplex, nft
status: live
website: https://www.nonfungiblebees.io/
twitter: https://twitter.com/NonFungibleBees
telegram:
discord: https://discord.gg/p2gcVTGrFv
---

This project will look nicely on the ecosystem page and very much advance
the Solana Ecosystem. All while following the community rules, and the ones
stated herein.
