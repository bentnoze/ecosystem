---
slug: "rox"
date: "2021-10-01"
title: "ROX"
logline: "Generative dArt. A first-of-its-kind generative, data-driven NFT project on the Solana blockchain."
cta: "https://rox.cards/"
logo: /img/rox-logo.svg
category: nft
status: live
website: https://rox.cards/
twitter: https://twitter.com/anchor_protocol
discord: https://discord.gg/DJFG4jvehF
---

Generative dArt. A first-of-its-kind generative, data-driven NFT project on the Solana blockchain.
