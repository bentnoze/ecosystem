---
slug: "goo"
date: "2021-06-01"
title: "Goo"
logline: "An upcoming protocol bringing decentralized, encrypted notifications to #web3. Built on Solana."
cta: "https://goo.software/"
logo: /img/Goo.svg
category: metaplex, nft
status: live
website: https://goo.software/
twitter: https://twitter.com/goosoftware
---

An upcoming protocol bringing decentralized, encrypted notifications to #web3. Built on Solana.
