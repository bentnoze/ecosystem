---
slug: "goodgamesguild"
date: "2021-09-16"
title: "Good Games Guild"
logline: "A Gaming hub focus on blockchain-based games. #Play2Earn movement! Metaverse for the living"
cta: "http://goodgamesguild.com/"
logo: /img/ggg.svg
category: app
status: Building
website: http://goodgamesguild.com/
twitter: https://twitter.com/goodgamesguild
telegram: https://t.me/GoodGamesGuildChat
discord: https://discord.gg/x47U9qkR5K
---

Good Games Guild (GGG) is a decentralized autonomous organization (DAO) that focus on non fungible tokens (NFTs) that oftenly used in blockchain-based games & virtual product.

We believe the future of gaming will be on the NFT & Blockchain technology, so we carry the mission to become the biggest hub for virtual world economy, NFT Gaming Community and Marketplace.
