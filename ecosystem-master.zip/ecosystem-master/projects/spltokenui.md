---
slug: "spl-ui"
date: "2020-04-03"
title: "SPL Token UI"
logline: "SPL Token UI is a platform that allows for the creation and management of SPL tokens."
cta: "https://www.spl-token-ui.com/"
logo: /img/spltokenui.svg
category: spl, app
status: building
---

SPL Token UI is an interface for creating and managing SPL Tokens.
