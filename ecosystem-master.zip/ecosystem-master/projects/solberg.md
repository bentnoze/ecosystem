---
slug: "solberg"
date: "2021-09-04"
title: "Solberg"
logline: "Solberg is a decentralized exchange that will support NFT marketplace and staking."
cta: "https://www.solbergtoken.com"
logo: /img/Solberg.svg
category: DEX, Exchange, nft
Status: live
website: https://www.solbergtoken.com
twitter: https://twitter.com/SolbergToken
telegram: https://t.me/solbergofficial
status: live
---

Through Solberg we decided to show all of the benefits of using Solana Blockchain. Our vision is to make a fully featured ecosystem for Staking and Trading that also supports NFT marketplace.
