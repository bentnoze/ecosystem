---
slug: "junglefinance"
date: "2021-06-01"
title: "Jungle Finance"
logline: "Jungle Finance is the liquid farming and staking solution for Solana-based assets."
cta: "https://jungledefi.io/"
logo: /img/Jungle-Finance.svg
category: metaplex, nft
status: live
website: https://jungledefi.io/
twitter: https://twitter.com/jungledefi
discord: https://discord.com/invite/gvtnbk6mfg
---

The liquid farming and staking solution for Solana-based assets. We’ll auto-compound your yield and send you a token representing your farm rewards as well as a token representing your locked assets, both of which can be redeemed at any time. Buy, sell, lend or borrow them independently!
