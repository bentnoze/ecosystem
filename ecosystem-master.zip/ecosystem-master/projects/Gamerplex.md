---
slug: "gamerplex"
date: "2021-07-02"
title: "gamer plex"
logline: "GAMERPLEX is an NFT marketplace based on the Solana network."
cta: "https://www.gamerplex.io/#/"
logo: /img/gamerplex_kinland.jpg
category: metaplex, nft
status: live
website: https://www.gamerplex.io/#/
twitter: https://twitter.com/kinland_game
discord: https://discord.com/invite/metaplex
---

GAMERPLEX is an NFT marketplace based on the Solana network and is a fork of the open-source Metaplex protocol. All NFT’s in this marketplace will be playable within the game they have been minted for. You can see releases on the 'Game Series' page where we currently show our Kinland drops. Use your Solana Wallet to use Metaplex to connect.
