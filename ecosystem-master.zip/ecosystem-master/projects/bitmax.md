---
slug: "ascendex"
date: "2020-04-03"
title: "AscendEX"
logline: "AscendEX (formerly BitMax) is a global digital assets trading platform that is quickly becoming a leading exchange in China, Korea, and Japan. BitMax listed SOL on July 20th, 2020."
cta: "https://ascendex.com"
logo: /img/ascendex.svg
category: exchange
status: live
twitter: https://twitter.com/ascendex_global
---

AscendEX (formerly BitMax) is a global digital assets trading platform based out of Singapore and has over 190 trading pairs and 40 different margin trading pairs.
