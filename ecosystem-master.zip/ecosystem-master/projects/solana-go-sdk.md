---
slug: "solana-go-sdk"
date: "2021-08-13"
title: "solana-go-sdk"
logline: "a solana sdk in go"
cta: "https://github.com/portto/solana-go-sdk"
logo: /img/solana-go-sdk.svg
category: sdk
status: live
---

solana-go-sdk as used in Blocto. You can use it to build your app. Follow our github project and you'll see the latest status.
