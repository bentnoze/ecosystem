---
slug: "bitfinex"
date: "2020-04-03"
title: "Bitfinex"
logline: "Bitfinex listed SOL in February of 2021."
cta: "https://www.bitfinex.com/"
logo: /img/bitfinex.svg
category: exchange
status: live
twitter: https://twitter.com/Bitfinex
---

Bitfinex listed Solana on 24/02/2021 at 9:00 AM UTC. SOL is available to trade with US Dollars (SOL/USD) and Tether tokens (SOL/USDt).
