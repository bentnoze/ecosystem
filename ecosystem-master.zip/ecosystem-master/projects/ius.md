---
slug: "ius"
date: "2021-10-20"
title: "IUS"
logline: "Island universe is an ecological currency based on the concept and implementation of meta universe. IUS is mainly committed to ecological construction and ecological empowerment. The birth of Ius is an enabling main chain ecological currency based on the ecological construction of the meta universe."
cta: "isLanduniverse.cn"
logo: /img/ius.png
category: dapp,nft,game
status: building
website: isLanduniverse.cn
twitter: https://twitter.com/hpetkhtqbdq
telegram: https://0.plus/IUSAIUNGT
discord: ---
---
Island universe is an ecological currency based on the concept and implementation of meta universe. IUS is mainly committed to ecological construction and ecological empowerment. The birth of Ius is an enabling main chain ecological currency based on the ecological construction of the meta universe.