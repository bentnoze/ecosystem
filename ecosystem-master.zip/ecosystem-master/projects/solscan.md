---
slug: "solscan.io"
title: "Solscan.io"
date: 2021-06-22
logline: "Solscan is a user-friendly and real-time update Scanning Tool for the Solana Ecosystem."
cta: "https://twitter.com/solscanofficial"
category: app, explorer
logo: /img/solscan.svg
status: Live
website: https://solscan.io/
twitter: https://twitter.com/solscanofficial
discord: https://discord.com/invite/H8FBqAR8bx
---

Solscan is a scanning tool that tracks all of Solana and Solana-related token transactions. Solscan provides users with all the information on SOL and Solana-based tokens.
