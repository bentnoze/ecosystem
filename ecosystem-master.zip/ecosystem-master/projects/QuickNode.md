---
slug: "quicknode"
date: "2017-07-01"
title: "QuickNode"
logline: "QuickNode makes it simple to power your blockchain applications and scale up as you grow."
cta: "https://www.quicknode.com/"
logo: /img/QuickNode.svg
category: metaplex, nft, infra
status: live
website: https://www.quicknode.com/
twitter: https://twitter.com/QuickNode
discord: https://discord.com/invite/DkdgEqE
---

Blockchain nodes for dApps and devs. Access ETH, BTC, BSC, MATIC, OPTIMISM, FTM, CELO, SOL, and xDAI data via API. Infra and tools to build + scale your #Web3 app.
We make it simple to power your blockchain applications and scale up as you grow. From elastic APIs and dedicated nodes, to powerful tools and analytics, a simple control panel can run all your commands.
