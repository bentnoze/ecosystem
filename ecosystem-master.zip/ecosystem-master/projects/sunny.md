---
slug: "Sunny"
date: "2021-03-01"
title: "Sunny"
logline: "Sunny is Solana’s first composable DeFi yield aggregator."
cta: "https://app.sunny.ag/"
logo: /img/sunny.svg
category: defi, amm
status: live
Website: https://app.sunny.ag/
Twitter: https://twitter.com/SunnyAggregator
Discord: https://discord.com/invite/dvXuvN9KeP
---

Sunny is Solana’s first composable DeFi yield aggregator. The Sunny Aggregator protocol is a decentralized protocol governed by the Sunny DAO. The Sunny Governance Token (“SUNNY”) will be used to make decisions about the future of the protocol.
