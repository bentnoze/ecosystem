---
slug: "definer"
title: "DeFiner"
date: 2021-06-22
logline: "DeFiner is a permission-less and configurable decentralized lending protocol with guaranteed privacy protection."
cta: "https://twitter.com/DeFinerOrg"
category: defi
logo: /img/definer.svg
status: Building
---

Built on Solana, DeFiner enables a scalable DeFi lending market which allows the community members to stake, borrow and lend for any tokens.
