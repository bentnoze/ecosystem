---
slug: "solpayments"
title: "SolPayments"
date: 2021-06-22
logline: "SolPayments is a payment processing platform for cryptocurrencies which allows individuals and businesses of all sizes to accept payments online"
cta: "https://twitter.com/SolPayments"
category: tools
logo: /img/solpayments.svg
status: Building
---

SolPayments is built on top of the Solana blockchain.
