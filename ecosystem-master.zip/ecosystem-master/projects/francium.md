---
slug: "francium"
title: "Francium"
date: 2021-06-22
logline: "Francium is a DeFi protocol built on Solana."
cta: "https://francium-protocol.io/"
category: defi
logo: /img/francium.svg
status: Live
website: https://francium-protocol.io/
twitter: https://twitter.com/Francium_Defi
telegram: https://t.me/joinchat/zxN7cvrWGmljNDJl
discord: https://discord.com/invite/qNcQwwRHwq
---

Francium is an innovative leveraged yield aggregator built on Solana bringing users continuous high APY through diverse community strategies.
