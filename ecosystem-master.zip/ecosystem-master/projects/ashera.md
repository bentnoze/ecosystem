---
slug: "ashera"
date: "2021-07-01"
title: "Ashera"
logline: "Ashera is a rebrand meme token on Solana. Ashera will focus on creating tools that work to help Solana Developer to develop their tokens."
cta: "https://asherasol.com/"
logo: /img/ashera.svg
category: dex, tools
status: building
---

Ashera will provide some features that will help many Solana Developers. Our features:

Ashera DEX
Dashboard Wallet
Ashera Tools
NFTs Marketplace
Discord Tip Bot
Discord Price Bot
