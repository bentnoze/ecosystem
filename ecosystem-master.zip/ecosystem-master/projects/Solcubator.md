---
slug: "solcubator"
date: "2021-10-17"
title: "Solcubator"
logline: "The First Permissionless and Community-Governed Launchpad on Solana."
cta: "https://www.solcubator.io"
logo: /img/solcubator.png
category: amm, app, dapp
status: building
website: https://www.solcubator.io
twitter: https://twitter.com/solcubator
telegram: https://t.me/Solcubator
---

Solcubator aims to drive the expansion and adoption of the Solana ecosystem by providing a secure and decentralized 
platform for projects seeking funding and incubation and for investors to filter the value-added projects as it's community-driven.
