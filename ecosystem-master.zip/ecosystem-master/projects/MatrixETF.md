---
slug: "matrixetf"
date: "2021-06-01"
title: "MatrixETF"
logline: "The next generation of ETF. Cross-chain enabled."
cta: "https://www.matrixetf.finance/"
logo: /img/Matrix.svg
category: defi
status: live
website: https://www.matrixetf.finance/
twitter: https://twitter.com/MatrixETF
telegram: https://t.me/MatrixETF
---

MatrixETF is a next generation decentralized ETF platform to run cross-chain. We are establishing a decentralized, automated, and diversified portfolio--tailored to the user--and ensuring users enjoy long-term, stable financial services.
