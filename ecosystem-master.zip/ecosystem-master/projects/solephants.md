---
slug: "solephants"
date: "2021-10-01"
title: "Solephants NFT"
logline: "Solephants are 7070 randomly generated cute elephant NFT project on the Solana blockchain featuring passive income."
cta: "https://solephants.io/"
logo: /img/solephants.svg
category: nft
status: live
website: https://solephants.io/
twitter: https://twitter.com/solephants
discord: https://discord.gg/UdpgvuMzBA
---

Solephants are 7070 randomly generated cute elephant NFT project on the Solana blockchain featuring passive income.

- Solephants: 7070 unique generative NFTs with attributes and a rarity system.
- Solephants project, which aims to create passive income for NFT owners through %100 Royalities profit sharing.
- Hodl-to-earn reward program
- Free Metaverse City Residence!
- Free Pet NFTs!

<b>Website</b>: https://solephants.io </br>
<b>Twitter</b>: https://twitter.com/solephants </br>
<b>Discord</b>: https://discord.gg/UdpgvuMzBA </br>
