---
slug: "starlaunch"
date: "2021-10-15"
title: "StarLaunch"
logline: "The first insured IDO launchpad for SOLANA"
cta: "https://www.starlaunch.com"
logo: /img/starlaunch.jpg
category: app
status: building
website: https://www.starlaunch.com
twitter: https://twitter.com/StarLaunchSOL
telegram: https://t.me/StarLaunchOfficial
medium: https://medium.com/@StarLaunch
---

StarLaunch is a launchpad and incubator for Solana blockchain projects, connecting them to our community of backers.
