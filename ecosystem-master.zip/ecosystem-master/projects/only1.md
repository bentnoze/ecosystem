---
slug: "only1"
date: "2021-05-28"
title: "Only1"
logline: "Only1 is an NFT-powered social engagement platform built on Solana."
cta: "https://twitter.com/only1nft"
logo: /img/only1.svg
category: nft
website: https://only1.io/
twitter: https://twitter.com/only1nft
telegram: https://t.me/only1nft
discord: https://discord.com/invite/sUu7KZwNCB
status: building
---

Only1 is an NFT-powered social engagement platform built on Solana.
Buy and sell NFTs from your favorite content creators, earn crypto through interactions, or mint your own NFTs and start earning rewards today. Powered by Solana.
