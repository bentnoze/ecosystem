---
slug: "SolPro"
date: "2021-08-08"
title: "SolPro"
logline: "SolPro——Solana Ecosystem Data Aggregation & Analytics Platform"
cta: "https://www.solpro.ai"
website: "https://www.solpro.ai"
twitter: "https://twitter.com/SolProProject"
telegram: "https://t.me/solpro_project"
category: defi, tools
status: live
logo: /img/solpro.svg
---

SolPro——Ecosystem Data Aggregation & Analytics Platform <br/>
Analyzes all of the projects within the Solana ecosystem to help you make better decisions. <br/>
 <br/>
SolPro in Action <br/>
——Full tracking of project performance <br/>
——Analyze project user characteristics <br/>
——Monitor and analyze top addresses <br/>
——Latest project news aggregation <br/>
