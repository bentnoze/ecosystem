---
slug: "soltipai"
date: "2021-10-01"
title: "SolTip AI"
logline: "A bot that allows you to send tip through your favorite social media."
cta: "https://soltip.ai"
logo: /img/soltipai.png
category: tools
status: live
website: https://soltip.ai/
twitter: https://twitter.com/soltip_ai
discord: https://discord.com/invite/uWAn8y92Ba
---

SolTip AI is the fastest on-chain tip bot allows you to send tip through your favorite social media. Reduce the risk of delivery errors and make it easier for you to send tips by simply mentioning or replying to someone's message.

SolTip AI has a very fast execution time. You just need less than a second to send a tip. We have its own RPC Node which can circumvent the rate limit.

SolTip AI is on-chain based, so you can see your transaction activity directly on the explorer website. This will provide extra security so that the user can monitor what is happening.

SolTip AI are now available on Discord. Long term, SolTip AI aims to build bots on Twitter and Telegram.
