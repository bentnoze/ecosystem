---
slug: "brz"
date: "2020-04-03"
title: "BRZ"
logline: "The Brazilian Real (BRL) backed stablecoin is now supported on the Solana blockchain."
cta: "https://www.brztoken.io"
logo: /img/brz.svg
category: stablecoin, spl
status: live
address: "https://explorer.solana.com/address/FtgGSFADXBtroxq8VCausXRr2of47QBf5AS1NtZCu4GD"
twitter: https://twitter.com/BrzToken
medium: https://medium.com/@BrzToken
reddit: https://www.reddit.com/user/BRZtoken
---

The BRZ stablecoin with a 1:1 peg to Brazilian Real. BRZ operates as a native asset on Solana.

The BRZ Cryptocurrency Board works with reputable Tellers around the world that buy and sell BRZ Tokens. After passing KYC/AML checks users will be able to purchase, transfer and sell BRZ tokens across multiple platforms.
Sales of BRZ Tokens for fiat currencies are performed according to the Teller's local jurisdiction procedures and regulations.

At the request of Transfero Swiss, creator of BRZ Token, the Law Firm, CMT - Carvalho, Machado and Timm Advogados, prepared a document that proves available funds to face existing assets, more specifically BRZ Token, the Brazilian stablecoin paired in Reais.
