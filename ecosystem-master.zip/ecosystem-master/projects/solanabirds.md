---
slug: "solanabirds"
date: "2021-10-07"
title: "Solana Birds"
logline: "A collection of 5,555 unique birbs, with some laying eggs!"
cta: "https://birbs.art/"
logo: /img/solanabirds.png
category: nft
status: live
website: https://birbs.art/
twitter: https://twitter.com/SolanaBirbs
discord: https://discord.com/invite/ZEaybetZGX
---

A collection of 5,555 unique birbs, with some laying eggs!
