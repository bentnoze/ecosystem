---
slug: "solible"
date: "2020-04-03"
title: "Solible"
logline: "Solible is an NFT exchange built on Project Serum."
cta: "https://solible.com"
logo: /img/solible.svg
category: dex
website: https://solible.com/#/
twitter: https://twitter.com/bonfida
telegram: https://t.me/bonfidatg
discord: https://discord.com/invite/B4xzATxQHC
status: live
---

Solible was the first NFT exchange to launch on Solana and Serum in October, 2020. Together with the help of Bonfida, Solible is continuing to build out their platform to offer more features and ways to interact with SPL Token NFT's.
