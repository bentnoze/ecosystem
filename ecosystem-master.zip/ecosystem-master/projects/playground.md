---
slug: "playground"
date: "2021-10-01"
title: "Playground"
logline: "Generative Artwork Immutably Stored on the Solana Blockchain."
cta: "https://www.playground.ink/"
logo: /img/playground.png
category: nft
status: live
website: https://www.playground.ink/
twitter: https://twitter.com/playground_sol
discord: https://discord.com/invite/9gzHXgZKUK
---

Generative Artwork Immutably Stored on the Solana Blockchain.
