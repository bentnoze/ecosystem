---
slug: "solanadon"
title: "Solanadon"
date: "2021-05-28"
logline: "Solanadon is building a community to help the endangered prehistoric mammal, Solenodons!"
cta: https://twitter.com/SolanadonCoin
category: defi
logo: /img/solanadoncoin.svg
status: building
---

Solenodons are small, venomous mammals that have been around since the dinosaurs--over 70 million years. We're aiming to bring the same longevity and survival power to Solana.
