---
slug: "harmonia-eko"
date: "2021-10-24"
title: "harmonia-eko"
logline: "harmonia-eko is the decentralized NFT x CO2 offset marketplace."
cta: "https://harmonia-eko.ghost.io"
logo: /img/harmonia-eko.png
category: NFT, dapp
status: building
website: "https://www.harmonia-eko.ghost.io"
discord: "https://discord.com/invite/Vh84sw3B"
twitter: "twitter.com/harmonia-eko"
---

_harmonia-eko_ is the Solana-powered CO2e offset marketplace, rewarding buyers with collectible and tradable NFT certificates, from the best of the web's artists!

🌳🌍🌏🌌😌
