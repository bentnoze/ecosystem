---
slug: "hazyhippos"
date: "2021-09-17"
title: "Hazy Hippos"
logline: "5,000 algorithmically generated hippos, all stored & distributed on the Solana blockchain. Over 4 million unique possible combinations."
cta: "https://hazyhippos.com/"
logo: /img/hazyhippos.png
category: nft
status: live
website: https://hazyhippos.com/
twitter: https://twitter.com/HazyHipposNFT
discord: https://discord.com/invite/SANVYCWsPx
---

5,000 algorithmically generated hippos, all stored & distributed on the Solana blockchain. Over 4 million unique possible combinations.
