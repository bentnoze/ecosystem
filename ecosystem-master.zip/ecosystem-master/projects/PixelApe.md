---
slug: pixelape
date: "2021-09-09"
title: PixelApe
logline: "The Pixel Apes are 10,000 unique pixel characters, created by a highly custom algorithm to generate the different features of the apes."
cta: "https://pixelape.art/"
logo: /img/pixelape.svg
category: nft
status: building
twitter: "https://twitter.com/pixelapeart"
---

The Pixel Apes are 10,000 unique pixel characters with different traits, created by a custom algorithm on Solana blockchain. All Pixel Apes mint use the Metaplex standard NFT, which widely used in the Solana ecosystem, you can send or trade your nfts by using the wallet and markets in Solana ecosystem.

discord: https://discord.gg/sS85BAruP2

twitter: https://twitter.com/pixelapeart
