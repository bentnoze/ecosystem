---
slug: "codifinance"
date: "2021-10-22"
title: "CODI Finance"
logline: "The protocol that enables financial ideas to become a reality."
cta: "https://codi.finance"
logo: /img/CODI_Finance.jpg
category: dex, nft
status: building
website: https://codi.finance/
twitter: https://twitter.com/Codi_Finance
telegram: https://t.me/codi_finance_community
discord: https://discord.gg/wWcySMFU
---

Vision
Compound Digital investors of all skill levels will find a wide range of products and easy-to-use desktop and mobile applications to their liking.

Mission
No gas fees, a diverse range of order types, the ability to buy and sell NFTs on the marketplace, and non-Custodial protocol, all without sacrificing anything.
