---
slug: "grimsyndicate"
date: "2021-10-03"
title: "Grim Syndicate"
logline: "Grim Syndicate is a 10,000 generative Grims launching on Solana. Serving the Ethereal Transit Authority since"
cta: "https://grimsyndicate.com/"
logo: /img/grimsyndicate.png
category: nft
status: live
website: https://grimsyndicate.com/
twitter: https://twitter.com/Grim__Syndicate
discord: https://discord.com/invite/grimsyndicate
---

Grim Syndicate is a 10,000 generative Grims launching on Solana. Serving the Ethereal Transit Authority since
