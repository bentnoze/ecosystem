---
slug: "chikin"
date: "2021-10-03"
title: "Chikin"
logline: "Disrupting the chicken society through decentralization."
cta: "https://chikin.run/"
logo: /img/chikin.svg
category: dapp, exchange, nft
status: live
website: https://chikin.run/
twitter: https://twitter.com/chikindev
discord: https://discord.gg/rsQQsAcAn7
---

More than 25 billion chickens alive in the world, and yet none of them have access to basic financial services.
The CHIKIN project was born in the head of an angry serama chicken, and aims to return chickens to their former glory when they were mighty dinosaurs.
