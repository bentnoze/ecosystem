---
slug: "antiartistclub"
date: "2021-10-22"
title: "Anti Artist Club"
logline: "2222 Randomly Generated Artists powered by Solana"
cta: "https://antiartist.club"
logo: /img/Anti_Artist_Club.jpg
category: nft
status: building
website: https://antiartist.club
twitter: https://twitter.com/antiartistclub
discord: https://discord.gg/C7Ru7G8Tv8
---

Anti artists have been crafted with a lot of thought with smooth animations for hair as well as bling and some other attributes. 
This isnt just another crypto pixel character clone.
