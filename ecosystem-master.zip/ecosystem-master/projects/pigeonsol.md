---
slug: "pigeonsol"
date: "2021-05-16"
title: "PigeonSol"
logline: "PigeonSol($PGNT) is a Decentralized exchange and NFT marketplace."
cta: "https://twitter.com/PigeonSol"
logo: /img/pigeonsol.svg
category: dex,metaplex
status: live
Website: http://solavatars.pigeonsol.xyz/
Twitter: https://twitter.com/PigeonSol
Discord: https://discord.com/invite/KHZGhJktYm
---

PigeonSol is deflationary token powered by Solana with a user friendly decentralized exchange and NFT marketplace.
