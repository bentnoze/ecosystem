---
slug: "ono"
date: "2021-06-01"
title: "Ono"
logline: "A next generation curated NFT marketplace designed with creators in mind. Built on Metaplex & Solana."
cta: "http://www.ono.art/"
logo: /img/Ono.svg
category: metaplex, nft
status: live
website: http://www.ono.art/
twitter: https://twitter.com/onodotart
discord: https://discord.gg/kMkMKp8aCs
---

Ono is a next generation curated NFT marketplace designed with creators in mind. Built on Metaplex & Solana.
