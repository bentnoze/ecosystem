---
slug: "solgangsta"
date: "2021-27-01"
title: "SolGangsta"
logline: "An NFT art for Gangsta built on Solana platform."
cta: "https://solgangsta.holaplex.com/#/"
logo: /img/solgangsta.jpg
category: metaplex, nft
status: live
website: https://solgangsta.holaplex.com/#/
twitter: https://twitter.com/solanagangnft
discord: https://discord.com/invite/jghtxruahq
---

SolGangsta is an NFT art for Gangsta built on Solana platform.
