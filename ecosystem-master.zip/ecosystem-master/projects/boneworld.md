---
slug: "boneworld"
date: "2021-10-03"
title: "Bone World"
logline: "Boneworld is a collection of 10,000 generative 3D Bone Avatars living as NFTs on the Solana blockchain with over 120+ traits across 5 categories. Each accessory presented in the collection was designed to reimagine the future of NFT gamification, digital fashion and metaverse."
cta: "https://www.boneworld.co/home"
logo: /img/boneworld.png
category: nft
status: live
website: https://www.boneworld.co/home
twitter: https://twitter.com/Boneworld_SOL
discord: https://discord.com/invite/boneworld
---

Boneworld is a collection of 10,000 generative 3D Bone Avatars living as NFTs on the Solana blockchain with over 120+ traits across 5 categories. Each accessory presented in the collection was designed to reimagine the future of NFT gamification, digital fashion and metaverse.
