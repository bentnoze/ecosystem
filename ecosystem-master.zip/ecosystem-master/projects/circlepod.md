---
slug: "circlepod"
date: "2020-07-23"
title: "Circlepod"
logline: "Circlepod: Next Generation Podcast combined with NFT and Solana, creates more interactivity and entertainment."
cta: "https://www.circlepod.app/"
logo: /img/circlepod.svg
category: nft, metaplex, app
status: building
website: https://www.circlepod.app/
twitter: https://twitter.com/CirclepodP
telegram: https://t.me/circlepod
discord: https://discord.gg/4rTM9tRV8s
---

Circlepod connects creatives and their supporters using blockchain technology. Using AI and data protocols, we are creating a fair, friendly copyright and subscription ecosystem.
