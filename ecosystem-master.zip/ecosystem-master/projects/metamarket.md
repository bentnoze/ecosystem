---
slug: "metamarket"
date: "2021-03-22"
title: "Metamarket"
logline: "MetaMarket is a Serum DEX with NFT minting and listing with interoperability incentives."
cta: https://github.com/ArcadeCity/metamarket
logo: /img/metamarket.svg
category: nft
website: https://github.com/ArcadeCity/metamarket
status: building
---

MetaMarket is a Serum DEX with NFT minting and listing with interoperability incentive, growing the open metaverse.
