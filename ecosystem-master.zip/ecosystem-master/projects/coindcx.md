---
slug: "coindcx"
date: "2020-04-03"
title: "CoinDCX"
logline: "CoinDCX maintains multiple SOL spot trading pairs."
cta: "https://coindcx.com/"
logo: /img/coindcx.svg
category: exchange
status: live
twitter: https://twitter.com/CoinDCX
---

CoinDCX is an exchange that has listed SOL, Solana's native currency.
