---
slug: "cryptogreeks"
date: "2021-10-05"
title: "Crypto Greeks"
logline: "A limited collection of 10,000 generative ancient Greek busts on the Solana blockchain."
cta: "https://cryptogreeks.io/"
logo: /img/greeks.png
category: nft
status: live
website: https://cryptogreeks.io/
twitter: https://twitter.com/SolCryptoGreeks
discord: https://discord.com/invite/CryptoGreeks
---

A limited collection of 10,000 generative ancient Greek busts on the Solana blockchain.
