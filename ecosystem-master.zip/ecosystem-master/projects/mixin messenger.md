---
slug: "mixinmessenger"
title: "Mixin Messenger"
date: "2021-06-22"
logline: "A free, lightning fast & decentralized network for transferring digital assets. Secure digital assets and messages on Mixin."
cta: "https://mixin.one/"
category: wallet
logo: /img/mixinmessenger.svg
status: live
website: https://mixin.one/
twitter: https://twitter.com/Mixin_Network
---

A free, lightning fast & decentralized network for transferring digital assets. Secure digital assets and messages on Mixin.
