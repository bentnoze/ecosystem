---
slug: "solalambo"
date: "2021-10-17"
title: "SolaLambo"
logline: "SOB is a decentralized community driven token whose focus is to support Solana Ecosystem and connect all Solana SPL token"
cta: "https://sob.finance"
logo: /img/Solambo.jpg
category: app,dex
status: building
website: https://sob.finance
twitter: https://twitter.com/SolaLambo
discord: https://discord.gg/sy2xymyc7J
---

SOB is a decentralized community driven token whose focus is to support Solana Ecosystem and connect all Solana SPL token
