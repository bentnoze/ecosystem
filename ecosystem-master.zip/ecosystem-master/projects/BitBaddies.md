---
slug: "bitbaddies"
date: "2021-10-16"
title: "Bit Baddies"
logline: "The first female NFT project on #Solana 25% of mint goes to charities."
cta: "https://baddies.pages.dev/"
logo: /img/bitbaddies.png
category: nft
status: live
website: https://baddies.pages.dev/
twitter: https://twitter.com/BitBaddies
discord: https://discord.com/invite/bitbaddies
---

The first female NFT project on #Solana 25% of mint goes to charities.
