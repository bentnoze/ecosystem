---
slug: "solar"
date: "2021-07-25"
title: "NFT Solar"
logline: "NFT Solar is a social NFT platform leveraging Metaplex protocol"
cta: "https://nft.solar/"
logo: /img/solar.svg
category: defi, nft, metaplex, app
status: building
---

NFT Solar is a social NFT platform where you can login through social media accounts or Solana wallets in order to create, transfer, and trade NFTs.
