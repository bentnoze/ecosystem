---
slug: "soldads"
date: "2021-10-17"
title: "SOLDads"
logline: "SOL Dads is the first NFT collection of the so called SOL Family."
cta: "https://solfamily.io"
logo: /img/SOLDads.png
category: nft
status: building
website: https://solfamily.io
twitter: https://twitter.com/sol_dads
discord: https://discord.gg/3297e5AmPm
---

SOL Dads is the first NFT collection of the so called SOL Family.
