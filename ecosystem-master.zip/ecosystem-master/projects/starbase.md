---
slug: "starbase"
date: "2021-10-06"
title: "Starbase"
logline: "10k generated NFT, STARBASE is a #Solana #NFT Astronauts Community."
cta: "https://solstarbase.ch/"
logo: /img/starbase.png
category: nft
status: building
website: https://solstarbase.ch/
twitter: https://twitter.com/yourproject
discord: https://discord.com/invite/solstarbase
---

10k generated NFT, STARBASE is a #Solana #NFT Astronauts Community.
