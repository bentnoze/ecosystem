---
slug: "identityswap"
date: "2020-04-03"
title: "IdentitySwap"
logline: "IdentitySwap is an Automatic Money Market (AMM) dApp that demonstrates decentralized identity on Solana."
cta: "https://github.com/civicteam/identity-swap"
logo: /img/identityswap.svg
category: AMM
status: closed
website: https://identity.civic.finance/
twitter: https://twitter.com/identityswap
---

IdentitySwap is an Automatic Money Market (AMM) dApp that demonstrates decentralized identity on the Solana SPL Token-Swap program. The program connects with Civic’s identity verification system.
