---
slug: "cryptzeroart"
date: "2021-10-19"
title: "CryptZeroArt"
logline: "CryptZero is a series of unique collectible avatars / personal profile NFTs with a horror genre theme on the Solana blockchain. "
cta: "https://cryptzero.io/"
logo: /img/cryptozeroart.png
category: nft
status: live
website: https://cryptzero.io/
twitter: https://twitter.com/CryptZeroArt
discord: https://discord.com/invite/BHwjhwV7DH
---

CryptZero is a series of unique collectible avatars / personal profile NFTs with a horror genre theme on the Solana blockchain.
