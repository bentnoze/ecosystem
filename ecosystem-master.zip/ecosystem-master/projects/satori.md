---
slug: "satori"
date: "2020-08-19"
title: "Satori Ventures"
logline: "Satori Ventures supports the long-term growth of Solana and Serum by providing incubation to early-stage projects in the ecosystem."
cta: "https://www.satorivc.com/"
logo: /img/satori.svg
category: fund
status: live
---

Satori VC, based in Hong Kong, is a multi-strategy VC and research firm established by a group of crypto-veteran with a mission to advance the ecosystem by supporting promising projects in the space. Leverage our connections, advisory and support to build the next cornerstone of the ecosystem.
