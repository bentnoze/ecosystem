---
slug: "spacerhinos"
date: "2021-10-17"
title: "Space Rhinos"
logline: "10k SolanaNFTs Rhinos traveled from space into the Metaverse"
cta: "https://www.spacerhinos.com/"
logo: /img/rhinos.png
category: nft
status: building
website: https://www.spacerhinos.com/
twitter: https://twitter.com/Space__Rhinos
discord: https://discord.com/invite/KUyMURpYpH
---

10k Solana NFTs Rhinos traveled from space into the Metaverse
