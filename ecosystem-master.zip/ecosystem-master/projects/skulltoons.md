---
slug: "skulltoons"
date: "2021-10-02"
title: "Skulltoons"
logline: "Skulltoons is a collection of 10,000 randomly generated skull NFTs on the blockchain. Hodlers of these rare collectibles make up our amazing community."
cta: "https://skulltoons.com/"
logo: /img/skulltoons.png
category: nft
status: building
website: https://skulltoons.com/
twitter: https://twitter.com/myskulltoons
discord: https://discord.com/invite/cGSq6Btm
---

Skulltoons is a collection of 10,000 randomly generated skull NFTs on the blockchain. Hodlers of these rare collectibles make up our amazing community.
