---
slug: "jesi"
date: "2021-08-31"
title: "Jesi"
logline: "Jesi is a vertically integrated, Metaverse property developer."
cta: "https://jesi.app/"
twitter: "https://twitter.com/jesi_app"
discord: "https://t.co/GIGqnURgup?amp=1"
logo: /img/jesi.svg
category: app, metaplex, nft
status: live
---

Jesi is building an NFT marketplace, interactive worlds, and tools for architecture and construction in the Metaverse. Trade buildings and components, broker land, find work, and more.
