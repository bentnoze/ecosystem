---
slug: "cryowar"
date: "2021-10-25"
title: "Cryowar"
logline: "Real-time PvPvP blockchain NFT PlayToEarn game built on Solana and UnrealEngine"
cta: "https://cryowar.com"
logo: /img/cryowar.png
category: game
status: building
website: https://cryowar.com
twitter: https://twitter.com/CryowarDevs
telegram: https://t.me/cryowar
discord: https://discord.com/invite/cryowar
facebook: https://www.facebook.com/cryowar/
---

NEXT-GEN BLOCKCHAIN MULTIPLAYER GAME
Jump right into battle and prove your valor in an action-packed mobile free-to-play 1v1v1 arena brawler.

MULTIPLAYER NFT
CRYOWAR is a real-time multiplayer PVP arena NFT game developed in Unreal Engine and on the Solana network.

AMALGAM
Cryowar is an amalgam between traditional gaming experience and best practices of the blockchain world, DAO voting, NFT, and decentralized finance (DEFI).

DEFLATIONARY
A gaming ecosystem with deflationary mechanisms that integrates staking with gameplay, allowing RPG stakers to earn better rewards through increasing their in-game skill and experience levels.

MULTI-BLOCKCHAIN MEDIEVAL METAVERSE
Our endgame is the creation of a multi-blockchain Medieval Metaverse without boundaries

FEATURING
CROSS-PLATFORM MULTIPLAYER
8 UNIQUE CHARACTERS
SKILL-BASED GAMEPLAY
