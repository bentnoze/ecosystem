---
slug: "culchain"
date: "2021-07-08"
title: "CulChain"
logline: "Culture preserved on the Solana Blockchain."
cta: https://culchain.world/
logo: /img/culchain.svg
category: nft
status: live
---

CulChain is a perfect symphony between blockchain and global mythologies, with an aim at preserving ancient cultures and their historical relevance through NFTs.
