---
slug: "flunkdonkeys"
title: "FlunkDonkeys"
date: 2021-09-10
logline: "The Donkeys of Solana."
category: nft
cta: https://twitter.com/FlunkDonkeys
logo: /img/flunkdonkeys.png
status: live
website: https://www.flunkdonkeys.com/com
twitter: https://twitter.com/FlunkDonkeys
discord: https://discord.gg/Rkk7dRZv5Y
---

Flunk Donkeys are 5,678 NFTs on the Solana blockchain. They are ready to build a FLUNK LEGACY on the Solana Blockchain and they make a lot of noise!
