---
slug: "goosefx"
date: "2021-10-20"
title: "GooseFX"
logline: "GooseFX is a DeFi platform with crypto and NFT trading built on Solana"
cta: "https://goosefx.io"
logo: /img/GooseFX.jpg
category: defi,nft
status: building
website: https://goosefx.io
twitter: https://twitter.com/GooseFX1
telegram: https://t.me/goosefx
discord: https://discord.com/invite/cDEPXpY26q
---

GooseFX is a DeFi platform with crypto and NFT trading built on Solana
