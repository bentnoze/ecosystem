---
slug: "mexc"
date: "2020-04-03"
title: "MEXC"
logline: "MEXC listed the SOL token in the Summer of 2020, and maintains multiple trading pairs."
cta: "https://www.mxc.com/"
logo: /img/mxc.svg
category: exchange, spl
twitter: https://twitter.com/MEXC_Global
status: live
---

The trading pairs live on MEXC are SOL/BTC and SOL/USDT. MEXC is a Hong Kong-based exchange with a global presence.
