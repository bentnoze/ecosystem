---
slug: ChihuahuaSol
date: "2021-08-22"
title: ChihuahuaSol
logline: "Exclusive NFTs Built on #Solana"
cta: "https://nft.chihuahuasol.com/"
logo: /img/ChihuahuaSol.svg
category: nft
status: live
twitter: "https://twitter.com/ChihuahuaSol"
---

ChihuahuaSol: Exclusive NFTs Built on #Solana

<b>Website</b>: https://chihuahuasol.com </br>
<b>Twitter</b>: https://twitter.com/ChihuahuaSol </br>
<b>NFT Marketplace</b>: https://nft.chihuahuasol.com/ </br>
