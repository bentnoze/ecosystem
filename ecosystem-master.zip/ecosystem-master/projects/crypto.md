---
slug: "crypto"
date: "2020-04-03"
title: "Crypto.com"
logline: "Crypto.com has multiple SOL spot trading pairs, and allows users to purchase SOL through debit cards and bank transfers."
cta: "https://crypto.com"
logo: /img/crypto.svg
category: wallet, exchange
status: live
---

On August 6th, 2020, Crypto.com listed SOL.

With SOL added to the Crypto.com app, users can now purchase at true cost with no fees - credit card and bank transfer both supported.

As Crypto.com also offers a Visa Card, this adds additional utility to SOL as users can easily convert cryptocurrencies into fiat currencies and spend at over 60 million merchants globally.
