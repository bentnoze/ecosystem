---
slug: "sodaprotocol"
date: "2021-06-18"
title: "SodaProtocol"
logline: "Soda is a native decentralized lending-borrowing protocol on Solana. "
cta: "https://twitter.com/SodaProtocol"
logo: /img/SodaProtocol.jpg
category: Defi
status: building
website: https://alpha.sodaprotocol.com/
twitter: https://twitter.com/SodaProtocol
discord: https://discord.com/invite/4r7uyyTR3V
---

Soda aims to provide a lending-borrowing market for all the valuable popular assets and emerging assets.
Soda also established an on-chain credit rating system based on address historical behaviors.
With these fantastic features, Soda will be the easiest to use and most secure DeFi platform.
