---
slug: "boringprotocol"
title: "Boring Protocol"
date: "2021-07-07"
logline: "Boring Protocol is a decentralized VPN built on Solana."
cta: "https://boringprotocol.io"
category: infra, app
logo: /img/boringprotocol.svg
status: live
website: https://boringprotocol.io/
twitter: https://twitter.com/BoringProtocol
telegram: https://t.me/tunnelgram
discord: https://discord.com/invite/ZrdHfMWg2w
---

Boring is a decentralized virtual private network and peer to peer bandwidth market built on the Solana Network, providing economic incentive for node providers with transparent programs for privacy to network users.
