---
slug: "solanapiranhas"
date: "2021-10-17"
title: "Solana Piranhas"
logline: "9,999 generative Piranhas on Solana"
cta: "https://www.solanapiranhas.com/"
logo: /img/piranhas.png
category: nft
status: live
website: https://www.solanapiranhas.com/
twitter: https://twitter.com/SolanaPiranhas
discord: https://discord.com/invite/solanapiranhas
---

9,999 generative Piranhas on Solana
