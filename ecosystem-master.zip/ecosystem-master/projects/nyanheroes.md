---
slug: "nyanheroes"
date: "2021-10-25"
title: "Nyan Heroes"
logline: "Become a Nyan Hero & save real cats! Play2Earn"
cta: "https://nyanheroes.com/"
logo: /img/nyan.png
category: nft
status: building
website: https://nyanheroes.com
twitter: https://twitter.com/nyanheroes
telegram: https://t.me/nyanheroes
discord: https://discord.gg/nyanheroes
---

Nekovia was once the greatest civilization in the metaverse. After centuries of peace, wealth and technological advancement, its citizens, the Nyans, began to believe themselves to be Gods in their own right.
At the top of the evolutionary food chain, they eventually saw fit to mold the world to suit their needs, rather than respect the laws of nature. They denounced their ancestors, 
their religions, and their cultures, and in doing so ruined their world.

By unlocking their secrets with blockchain technology and cryptography, you adventurers have given the Nyans a new power that is limitless in its potential.
As your Heroes embrace this new world paradigm and understand the potential that is offered, they call forth mighty Guardians and seek to take back what was once lost.
