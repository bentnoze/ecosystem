---
slug: "solanart"
date: "2021-07-10"
title: "Solanart"
logline: "Solanart is the first NFT marketplace on Solana. Get quick, easy access to digital collectibles, and explore, buy, and sell NFTs from different collections and artists."
cta: "https://solanart.io/"
logo: /img/solanart.svg
category: nft
status: building
---

Solanart is the first NFT marketplace on Solana. Get quick, easy access to digital collectibles, and explore, buy, and sell NFTs from different collections and artists.
