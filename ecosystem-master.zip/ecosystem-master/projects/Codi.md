---
slug: "codi_finance"
date: "2020-09-02"
title: "Codi Finance"
logline: "The IDO Protocol facilitates the realization of broad ecosytem financial ideas."
cta: "https://www.codi.finance/"
logo: /img/Codilogo.png
category: dex,nft
status: Building
website: https://www.codi.finance/
twitter: https://twitter.com/codi_finance
discord: https://discord.gg/cMz7SBfq
---

The key feature is the CODI IDO Launchpad. The CODI ecosystem aspires to be far broader, with the goal of developing a peer-to-peer NFT marketplace in add to a slew of additional Dapps.
