---
slug: "a-tun"
date: "2021-09-09"
title: "A-tun NFT"
logline: "'A-tun NFT' is not only a unique NFT series originally created by voxel artist katxii, Each 'A-tun NFT' will have a 10% probability of receiving an SOL airdrop after the new batch of NFT is sold out."
cta: "https://a-tun.cc/"
logo: /img/a_tun.png
category: metaplex, nft
status: live
website: https://a-tun.cc/
twitter: https://twitter.com/__katxii
discord: https://discord.gg/Y7Cs3CaF4y
---

"A-tun NFT" is not only a unique NFT series originally created by voxel artist katxii, Each "A-tun NFT" will have a 10% probability of receiving an SOL airdrop after the new batch of NFT is sold out.
