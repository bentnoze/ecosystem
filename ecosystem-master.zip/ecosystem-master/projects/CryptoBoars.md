---
slug: "cryptoboars"
date: "2021-09-26"
title: "Crypto Boars"
logline: "CryptoBoars is an NFT project featuring exclusive, limited run, handmade NFT artworks available on the Solana blockchain."
cta: "https://cryptoboars.holaplex.com/"
logo: /img/boars.png
category: nft
status: live
website: https://cryptoboars.holaplex.com/
twitter: https://twitter.com/CryptoBoars
discord: https://discord.com/invite/p88vtFAEU9
---

CryptoBoars is an NFT project featuring exclusive, limited run, handmade NFT artworks available on the Solana blockchain.

Marketplace:
https://cryptoboars.holaplex.com/
https://ftx.us/nfts/collection/Crypto%20Boars/
