---
slug: "solpass"
date: "2021-10-14"
title: "Solpass"
logline: "One of a kind pass to NFT privileges & community"
cta: "https://solpass.io/"
logo: /img/solpass.png
category: nft
status: live
website: https://solpass.io/
twitter: https://twitter.com/SolPassNFT
discord: https://discord.com/invite/solpass
---

One of a kind pass to NFT privileges & community
