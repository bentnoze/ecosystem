---
slug: "solskull"
date: "2021-08-30"
title: "solskull"
logline: "solskull is a skull nft built on solana blockchain."
cta: "https://solanaskull.com/"
logo: /img/SolSkull.svg
category: nft
status: building
---

SolSkull is a skull NFT built on Solana.
