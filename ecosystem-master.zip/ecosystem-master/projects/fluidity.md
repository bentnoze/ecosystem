---
slug: "fluidity"
title: "Fluidity"
date: "2021-05-28"
logline: "Fluidity rewards users when they interact with cryptocurrencies."
cta: https://twitter.com/fluiditymoney
category: stablecoin, defi
logo: /img/fluidity.svg
status: Building
---

Fluidity allows Solana based assets to be converted into a Fluid version that rewards users when they use them. Fluidity will launch on Solana and integrate with Solana based Defi Protocols. Fluidity is also a Solana Grant recipient.
