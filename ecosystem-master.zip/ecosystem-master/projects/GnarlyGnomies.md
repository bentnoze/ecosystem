---
slug: "Gnarly Gnomies"
date: "2021-09-06"
title: "Gnarly Gnomies"
logline: "Started from the Garden now we are here! Gnarly Gnomies are a unique NFT project of all handcrafted Gnomes Gnomies by a small group of artists!"
cta: "https://digitaleyes.market/collections/Gnarly%20Gnomies"
logo: /img/gnarlygnomieslogo.jpeg
category: nft
status: live
twitter: https://twitter.com/DigitalEyesNFT
---

Started from the Garden now we are here! Gnarly Gnomies are a fun and unique NFT project of all handcrafted Gnomes <b>Gnomies</b> by a small group of artists!
