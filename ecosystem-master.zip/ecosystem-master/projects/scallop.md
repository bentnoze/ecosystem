---
slug: "scallop"
date: "2021-06-19"
title: "Scallop"
logline: "Scallop is a DeFi game on Solana. Stake to win tokens and NFTs✨!"
cta: "https://www.scallop.io/"
logo: /img/scallop.svg
category: defi, app, game, NFT
status: building
website: https://www.scallop.io/
twitter: https://twitter.com/Scallop_io
telegram: https://t.me/scallop_io
---

Scallop is a Defi game on Solana. Users can stake their SOL to grow a "scallop" and have chances at winning tokens and NFTs. At the end of each week, one or more winners will be chosen at random to share out some of the stake. 7% of SOL reward will be kept in the staking pool, 93% will be SCA buyback. During the game, users can win Scallop Decorations by carrying out tasks✨!

<b>Website</b>: https://www.scallop.io/ </br>
<b>Twitter</b>: https://twitter.com/Scallop_io </br>
<b>Discord</b>: https://discord.gg/F7umecFArJ </br>
<b>Telegram</b>: https://t.me/scallop_io </br>
<b>Instagram</b>: https://www.instagram.com/scallop.io </br>
<b>Facebook</b>: https://www.facebook.com/Scallop.io </br>
<b>Medium</b>: https://scallopio.medium.com </br>
