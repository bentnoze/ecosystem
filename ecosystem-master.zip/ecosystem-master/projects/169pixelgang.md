---
slug: "169pixelgang"
date: "2020-09-10"
title: "169 Pixel Gang"
logline: "169 Pixel Gang is a streetwear in metaverse and real world"
cta: "https://169pixel.com/"
logo: /img/169pixelgang.svg
category: nft
status: live
website: https://169pixel.com/
twitter: https://twitter.com/169pixel
discord: https://discord.gg/5gXmXPBpCv
---

169 Pixel Gang is a NFT launching 2nd October that will be launching streetwear clothing into the metaverse & real world, as well as facilitating launches for fashion brands into the metaverse.
