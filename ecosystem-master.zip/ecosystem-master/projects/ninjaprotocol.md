---
slug: ninjaprotocol
date: "2021-08-22"
title: Ninja Protocol
logline: >-
  Ninja Protocol is an ecosystem product developed on the Solana blockchain
  with a focus on gaming & NFTs.
cta: "https://ninjaprotocol.io/"
logo: /img/ninjaprotocol.svg
category: "dex, nft, app"
status: building
twitter: "https://twitter.com/NINJASolProto"
---

Ninja Protocol is an ecosystem product developed on the Solana blockchain with a focus on gaming & NFTs.

<b>Website</b>: https://ninjaprotocol.io/ </br>
<b>Ninja Dex</b>: https://betadex.ninjaprotocol.io/ </br>
<b>Ninja Profile</b>: https://profile.ninjaprotocol.io/ </br>
<b>Twitter</b>: https://twitter.com/NINJASolProto </br>
<b>Telegram</b>: https://t.me/joinchat/u1YLLZHQcvM1YTU0 </br>
<b>Discord</b>: https://discord.gg/ninjaprotocol </br>
