---
slug: "solsouls"
date: "2021-10-05"
title: "Sol Souls"
logline: "10,000 uniquely generated, cute and collectible pixel art souls with proof of ownership stored on the Solana blockchain."
cta: "https://solsoulsnft.com/"
logo: /img/solsouls.png
category: nft
status: live
website: https://solsoulsnft.com/
twitter: https://twitter.com/SolSoulsNFT
discord: https://discord.gg/KUr9vvdQKy
---

10,000 uniquely generated, cute and collectible pixel art souls with proof of ownership stored on the Solana blockchain.
