---
slug: "skeletoncrew"
date: "2021-10-01"
title: "Skeleton Crew"
logline: "SKULLS are a collection of 6,666 hand-drawn and algorithmically generated NFTs on the Solana blockchain. Every SKULL features original artwork and is randomly and uniquely assembled from over 400k total options."
cta: "https://skeletoncrew.rip/"
logo: /img/skelcrew.png
category: nft
status: live
website: https://skeletoncrew.rip/
twitter: https://twitter.com/skeletoncrewrip
discord: https://t.co/zyDmzV8CYH?amp=1
---

SKULLS are a collection of 6,666 hand-drawn and algorithmically generated NFTs on the Solana blockchain. Every SKULL features original artwork and is randomly and uniquely assembled from over 400k total options.
