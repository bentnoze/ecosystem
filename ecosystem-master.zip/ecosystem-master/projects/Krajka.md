---
slug: "krajka"
date: "2021-04-01"
title: "Krajka"
logline: "New tech enthusiast, AR and Content Creator."
cta: "https://krajka.holaplex.com/#"
logo: /img/ARThings.svg
category: metaplex, nft
status: live
website: https://krajka.holaplex.com/#
twitter: https://twitter.com/zibi67868634
---

Krajka is a technological enthisiast, artist, and content Creator.
