---
slug: "moonpay"
date: "2020-04-03"
title: "Moonpay"
logline: "Moonpay is a fiat on-ramp that allows users to seamlessly integrate cryprocurrency payments into their applications."
cta: "https://www.moonpay.com/"
logo: /img/moonpay.svg
category: infra
status: live
---

MoonPay makes it easy to launch cryptocurrency on and off-ramps inside your application in minutes. SOL is supported in international locales.
