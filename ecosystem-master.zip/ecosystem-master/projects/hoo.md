---
slug: "hoo"
date: "2020-04-03"
title: "Hoo"
logline: "Hoo has multiple SOL spot trading pairs on their exchange."
cta: "http://hoo.com/"
logo: /img/hoo.svg
category: exchange
status: live
---

Hoo is an exchange that listed SOL, Solana's native currency. You can trade SOL on hoo.com and explore their offerings.
