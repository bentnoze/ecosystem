---
slug: "parametrise"
date: "2021-09-29"
title: "Parametrise"
logline: "Growing Library of Parametric NFT Collections"
cta: "https://parametrise.com/"
logo: /img/parametrise.png
category: nft
status: live
website: https://parametrise.com/
twitter: https://twitter.com/Parametrise_NFT
discord: https://discord.gg/kMkMKp8aCs
---

Anchor is a savings protocol that aims to produce a simple and
convenient savings product with broad appeal to everyday users.
