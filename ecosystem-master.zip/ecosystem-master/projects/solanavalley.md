---
slug: "solanavalley"
date: "2021-10-09"
title: "Solana Valley"
logline: "10,000 collectible, adorable, and friendly cows will be available in the Series 1 drop and stored on the Solana blockchain!"
cta: "https://yourwebsite.tld/call-to-action"
logo: /img/solanavalley.png
category: nft, game
status: live
website: https://yourwebsite.tld/
twitter: https://twitter.com/SolanaValley
discord: https://discord.com/invite/solanavalley
---

10,000 collectible, adorable, and friendly cows will be available in the Series 1 drop and stored on the Solana blockchain!
