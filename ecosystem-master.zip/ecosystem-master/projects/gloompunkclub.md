---
slug: "gloompunkclub"
date: "2021-10-03"
title: "Gloom Punk Club"
logline: "Gloom Punk Club is a dystopian mystery, with beautifully rendered, hand-drawn art. Uncover the secrets with a first of its kind unlockable story told only through NFT drops."
cta: "https://gloompunkclub.com/"
logo: /img/gloompunk.png
category: nft
status: live
website: https://gloompunkclub.com/
twitter: https://twitter.com/gloompunkclub
discord: https://discord.com/invite/uudGTzvGBu
---

Gloom Punk Club is a dystopian mystery, with beautifully rendered, hand-drawn art. Uncover the secrets with a first of its kind unlockable story told only through NFT drops.
