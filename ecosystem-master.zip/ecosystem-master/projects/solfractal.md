---
slug: "solfractal"
date: "2021-10-06"
title: "Sol Fractal"
logline: "Bringing HD Quality Art to Solana. Make $ By Holding. 10,000 Individually Designed Fractals. "
cta: "https://solfractals.art/"
logo: /img/solfractal.png
category: nft
status: live
website: https://solfractals.art/
twitter: https://twitter.com/SolFractals
discord: https://discord.gg/solfractals
---

Bringing HD Quality Art to Solana. Make $ By Holding. 10,000 Individually Designed Fractals.
