---
slug: "solaris"
date: "2021-03-22"
title: "Solaris"
logline: "Solaris is a Lending/Borrowing protocol that brings Flashloans to Solana blockchain (inspired by Aave and Compound)."
cta: https://solarisprotocol.com/
logo: /img/solaris.svg
category: DeFi
website: https://solarisprotocol.com/
twitter: https://twitter.com/solarisprotocol
telegram: https://t.me/SolarisProtocol
discord: https://discord.com/invite/pJh4TuuzEp
status: live
---

Solaris is a protocol for DeFi users that allows for earning interest on deposits and borrowing assets.
