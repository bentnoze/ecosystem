---
slug: "solape"
date: "2021-05-11"
title: "Sol Ape"
logline: "Sol Ape is a Serum-based DEX and deflationary token built on Solana."
cta: "https://www.solape.io/"
category: dex
logo: /img/solape.png
website: https://www.solape.io/
twitter: https://twitter.com/SolApeFinance
telegram: https://t.me/SolApeOfficial
discord: https://discord.com/invite/solape
status: live
---

Solape is a Serum-based Solana DEX built by apes, for other apes.

Solape Finance was created with the belief that crypto and blockchain tech appeal to the masses through easy-accessibility. Bringing forth an ecosystem that is rewarding and fun fulfills this desire. As firm believers in Solana, our goal is supplying fellow apes with an onboarding point to the crypto domain, or for existing members to experience it in a whole new light. Our Decentralized Exchange (DEX) serves not only as a place to trade the highest market cap coins, but also bolsters new projects within Solana with a platform to list their tokens, and deliver their communities a center to trade them.
