---
slug: "spiderswap"
title: "SpiderSwap"
date: 2021-06-22
logline: "SpiderSwap is a GUI for Serum + Staking SPW."
cta: "https://twitter.com/spider_swap"
category: dex
logo: /img/spiderswap.svg
status: Building
---

SpiderSwap facilitates Serum liquidity + SPL token staking.
