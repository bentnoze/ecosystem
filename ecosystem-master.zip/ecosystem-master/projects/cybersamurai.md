---
slug: "cybersamurai"
date: "2021-09-26"
title: "Cyber Samurai"
logline: "The Samurai are digitable collectibles living on the Solana blockchain. The NFTs in our collection will accrue additional value through various avenues. NFTs are bringing the masses to Solana, and we want to help provide exposure to premier Solana projects via our digital artwork, comics, and merch."
cta: "https://cybersamurai.co/#"
logo: /img/cybersamurai.png
category: nft
status: building
website: https://cybersamurai.co/#
twitter: https://twitter.com/CyberSamuraiNFT
discord: https://t.co/swzahtAFj5?amp=1
---

The Samurai are digitable collectibles living on the Solana blockchain. The NFTs in our collection will accrue additional value through various avenues. NFTs are bringing the masses to Solana, and we want to help provide exposure to premier Solana projects via our digital artwork, comics, and merch.
