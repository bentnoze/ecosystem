---
slug: "atomic"
date: "2020-04-03"
title: "Atomic"
logline: "Atomic is a non-custodial crypto wallet and payments gateway that supports SOL and SPL tokens."
cta: "https://atomicwallet.io"
category: wallet, SPL, exchange
logo: /img/atomic.png
status: live
website: https://atomicwallet.io/
twitter: https://twitter.com/atomicwallet
telegram: https://t.me/AtomicWalletNews
---

Atomic is a non-custodial crypto wallet that provides support for SOL and SPL tokens built on the Solana network. Atomic also offers payment gateway features and crypto on-ramp capabilities.
