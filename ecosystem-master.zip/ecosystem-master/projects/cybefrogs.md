---
slug: "cyberfrogs"
date: "2021-10-10"
title: "Cyber Frogs"
logline: "Cyber Frogs are a collection of 8888 randomly generated Frogs stored on the Solana blockchain, made with over 130 unique traits of varying rarity. Each Cyber Frog is non-sequentially minted and provably unique."
cta: "https://cyberfrogs.io/"
logo: /img/cyberfrogs.png
category: nft
status: live
website: https://cyberfrogs.io/
twitter: https://twitter.com/CyberFrogsNFT
discord: https://discord.com/invite/EkTxRBwHGF
---

Cyber Frogs are a collection of 8888 randomly generated Frogs stored on the Solana blockchain, made with over 130 unique traits of varying rarity. Each Cyber Frog is non-sequentially minted and provably unique.
