---
slug: "fractality"
date: "2020-09-30"
title: "Fractality"
logline: "Exploring Fractal Worlds"
cta: "https://www.fractalityworld.io"
logo: /img/fractalityworld.png
category: nft
status: building
website: https://www.fractalityworld.io
twitter: https://twitter.com/FractalityWorld
discord: https://discord.gg/y99tej8FQ2
---

There are multiple attributes in each fractal. However only 2 attributes determine the rarity: Zoom and Timeline.
Higher zooms are more rare and Timelines represent where the fractal exists. Golden Ages and Oblivion Fractals are the most rare.
