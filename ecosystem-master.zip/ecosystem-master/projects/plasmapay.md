---
slug: "plasmapay"
date: "2020-04-03"
title: "PlasmaPay"
logline: "PlasmaPay is a fiat onramp that allows users to seamlessly integrate cryprocurrency payments into their applications."
cta: "https://plasmapay.com"
logo: /img/plasmapay.svg
category: infra
status: live
website: https://plasmapay.com
twitter: https://twitter.com/0xPlasma
telegram: https://t.me/plasmapay_community
---

PlasmaPay makes it easy to launch cryptocurrency on and off-ramps inside your application in minutes. SOL is supported on their platform.
