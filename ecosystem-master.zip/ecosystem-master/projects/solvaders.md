---
slug: "solvaders"
date: "2021-10-08"
title: "Solvaders"
logline: "An invasion of 333 unique and randomly generated Solvaders coming to earth.
Take your chance to ally with them!"
cta: "https://solvaders.io/"
logo: /img/solvaders.png
category: nft
status: live
website: https://solvaders.io/
twitter: https://twitter.com/SolvadersNFT
---

An invasion of 333 unique and randomly generated Solvaders coming to earth.
Take your chance to ally with them!
