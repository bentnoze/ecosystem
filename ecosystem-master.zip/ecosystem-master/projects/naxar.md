---
slug: "naxar"
date: "2021-10-25"
title: "Naxar"
logline: "token for first decentralize mobile application no fee for transactions, Boxch"
cta: "https://www.naxar.ru"
logo: /img/naxar.png
category: app
status: building
website: https://www.naxar.ru
twitter: https://twitter.com/_Naxar
telegram: https://t.me/naxar_official
discord: https://discord.gg/7DdvxkEh4Q
---

Naxar and Boxch built on a Solana. Boxch this is: - Secret keys and seed-phrase are stored only on your phone, on the fastest blockchain, Solana.
If you have another wallet where Naxars are stored, 
you can enter it through Boxch using your seed phrase. - You can send Naxars anywhere in the world without paying any transfer fees.
