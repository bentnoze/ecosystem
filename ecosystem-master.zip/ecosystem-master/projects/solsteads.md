---
slug: "solsteads"
date: "2021-10-02"
title: "Solsteads"
logline: "Each Solstead is one of 2,472 unique homes in the first ever digital real estate on the Solana blockchain."
cta: "https://solsteads.com/"
logo: /img/solsteads.png
category: nft
status: live
website: https://solsteads.com/
twitter: https://twitter.com/SolsteadsNFT
discord: https://discord.com/invite/2MXFGd5Ndm
---

Each Solstead is one of 2,472 unique homes in the first ever digital real estate on the Solana blockchain.
