---
slug: aphid
date: "2021-08-18"
title: Aphid
logline: The Aphid ecosystem utilizes the aBion token on Solana to power digital bots to work tasks to earn money for people.
cta: "https://aphid.io/abion/"
logo: /img/aphid.png
category: dapp
status: building
twitter: "https://twitter.com/AphidAI"
---

By utilizing Artificial Intelligence, consumers and businesses leverage their time from the efforts of bots they control.
The Aphid ecosystem utilizes the aBion token on Solana to power digital bots to work tasks to earn money for people.

<b>Website</b>: https://aphid.io/abion/ </br>
<b>Twitter</b>: https://twitter.com/AphidAI </br>
<b>Discord</b>: https://discord.gg/mNHaVkm</br>
<b>Telegram</b>: https://t.me/AphidAI </br>
