---
slug: "aiko"
date: "2021-09-29"
title: "I'M AIKO"
logline: "I'M AIKO, I'm a new concept of NFT-ART based on AI. I'm a virtual companion developed by artificial intelligence."
cta: "https://aiko.io/"
logo: /img/aiko.png
category: nft, metaplex
status: building
Website: https://aiko.io/
Twitter: https://twitter.com/aikonft
Telegram: https://t.me/aikontf
Discord: https://discord.gg/xPggehqncs
---

I'M AIKO, I'm a new concept of NFT-ART based on AI. I'm a virtual companion developed by artificial intelligence.
