---
slug: "redpandasquad"
date: "2021-10-09"
title: "Red Panda Squad"
logline: "Hand-drawn from scratch by our truly skilled artist JK, there will only exist a maximum of 10.000 algorithmically generated, unique, cute red panda NFTs in this space. Ever."
cta: "https://redpandasquad.com/"
logo: /img/redpandasquad.png
category: nft
status: live
website: https://redpandasquad.com/
twitter: https://twitter.com/Red_Panda_Squad
discord: https://discord.com/invite/redpandasquad
---

Hand-drawn from scratch by our truly skilled artist JK, there will only exist a
maximum of 10.000 algorithmically generated, unique, cute red panda
NFTs in this space. Ever.
