---
slug: "blockbeats"
date: "2021-06-01"
title: "Blockbeats"
logline: "Produced and visualized for the new wave of music entertainment."
cta: "https://twitter.com/blockbeatsnft"
logo: /img/Blockbeats.svg
category: metaplex, nft
status: live
twitter: https://twitter.com/blockbeatsnft
telegram: https://t.me/blockbeatsclub
---

Produced and visualized for the new wave of music entertainment. Building a unique sound experience powered by Solana.
