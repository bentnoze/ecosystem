---
slug: "sollock"
title: "SOLLock"
date: 2021-07-25
logline: "The Safest LaunchPad built on SOLANA"
website: "https://sollock.io/#"
category: infra
logo: /img/sollock.svg
status: live
cta: "https://sollock.io/#"
twitter: https://twitter.com/SOLLockOfficial
telegram: https://t.me/SOLLockAnn
---

SOLLock is developed to offer developers and investors a safe place to work, as well as a way to prevent immediate sell-offs and rug-pulls after token releases. The SOLLock Locker platform allows investors to lock up any SPL-based token instantly.
