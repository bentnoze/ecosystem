---
slug: "eizperchain"
date: "2021-08-30"
title: "Eizper Chain"
logline: "Eizper Chain is F2P-P2E ARPG Game set in a high-fantasy world with steampunk style powered by Solana."
cta: "https://www.eizperchain.com"
logo: /img/eizperchain.jpg
status: building
category: "app, game, nft, spl, community, metaplex"
website: https://www.eizperchain.com
instagram: https://www.instagram.com/eizperchain
twitter: https://twitter.com/EizperChain
medium: https://medium.com/@eizperchain
discord: https://discord.gg/f38VNccHAm
---

Eizper Chain is a blockchain action online multiplayer role-playing game that celebrates adventure and arena battle. In the adventure, part players roam the fast world of Eizper following an epic story full of twists and turns. While in arena battle, players may compete against each other in battle events for a chance at rewards and recognition.

Eizper Chain aims to build triangle connections between Game Play, Free-to-Play (F2P), Play-to-Earn (PTE), NFT-Defi,and DAO.

<b>Website</b>: https://www.eizperchain.com</br>
<b>Instagram</b>: https://www.instagram.com/eizperchain</br>
<b>Twitter</b>: https://twitter.com/EizperChain</br>
<b>Medium</b>: https://medium.com/@eizperchain</br>
<b>Discord</b>: https://discord.gg/f38VNc
