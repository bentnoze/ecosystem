---
slug: "labyrint"
date: "2021-10-17"
title: "Synesthesia"
logline: "Labyrinth is a digital art collective creating generative artwork on the Solana blockchain. We strive to create cutting edge digital art that visually stimulates while also inviting introspection and deep reflection."
cta: "https://labyrinthart.xyz/#/"
logo: /img/labyrint.png
category: nft
status: live
website: https://labyrinthart.xyz/#/
twitter: https://twitter.com/_Labyrinth_Art_
discord: https://discord.com/invite/4Qx4Vnh3Sr
---

Labyrinth is a digital art collective creating generative artwork on the Solana blockchain. We strive to create cutting edge digital art that visually stimulates while also inviting introspection and deep reflection.
