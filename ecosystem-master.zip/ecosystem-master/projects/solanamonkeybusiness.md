---
slug: "smb"
date: "2021-07-01"
title: "Solana Monkey Business"
logline: "SolanaMonkeyBusiness is an NFT project on the Solana blockchain featuring two NFT collections."
cta: "https://www.solanamonkey.business/"
logo: /img/solanamonkeybusiness.svg
category: nft
status: live
website: https://market.solanamonkey.business/
twitter: https://twitter.com/solanambs
telegram: https://t.me/solanamonkeybusiness
discord: https://discord.com/invite/dEnYkASn7N
---

SolanaMonkeyBusiness is an NFT project on the Solana blockchain featuring two NFT collections:

- SolanaMonkeys: 5000 unique generative NFTs with attributes and a rarity system.
- SpaceMonkeys: 4 non-unique NFTs, granting the holders of the entire collection royalties on each SolanaMonkeys mint and trade, forever.
