---
slug: "solrisefinance"
date: "2021-03-22"
title: "Solrise Finance"
logline: "Solrise is a decentralized fund management and investment protocol on Solana."
cta: https://solrise.finance/
logo: /img/solrise.png
category: DeFi
website: https://solrise.finance/
twitter: https://twitter.com/SolriseFinance
telegram: https://t.me/solrisefinance
discord: https://discord.com/invite/xNbGgMUJfU
status: building
---

We have built a decentralized fund management and investment protocol on Solana. On-chain asset swapping, price discovery and oracles made this a pretty natural idea to implement.
