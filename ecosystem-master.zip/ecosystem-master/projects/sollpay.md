---
slug: "sollpay"
date: "2021-03-22"
title: "Sollpay"
logline: "Sollpay enables recurring Payments or subscriptions with the ability to periodically claim approved tokens by specified in plan amount and interval."
cta: https://github.com/sollpay/sollpay-frontend
logo: /img/sollpay.svg
category: DeFi, tools
status: building
---

Sollpay enables recurring Payments or subscriptions with the ability to periodically claim approved tokens by specified in plan amount and interval.
