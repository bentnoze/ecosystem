---
slug: "peeps"
date: "2021-10-16"
title: "The Peeps"
logline: "PEEPs are 10,000 unique block peeple for you to collect! Minted on the Solana blockchain, PEEPs are quirky, chirpy, and every single one has an incredibly unique personality!"
cta: "https://thepeeps.show/"
logo: /img/peeps.png
category: nft
status: live
website: https://thepeeps.show/
twitter: https://twitter.com/thepeepsnft
discord: https://discord.com/invite/n9QATdQWYc
---

PEEPs are 10,000 unique block peeple for you to collect! Minted on the Solana blockchain, PEEPs are quirky, chirpy, and every single one has an incredibly unique personality!
