---
slug: "solanapaint"
date: "2021-10-03"
title: "Solana Paint"
logline: "Futuristic Arts on Solana"
cta: "https://solanapaint.art/"
logo: /img/solanapaint.png
category: nft
status: live
website: https://solanapaint.art/
twitter: https://twitter.com/SolanaPaint
---

Our mission is to create the best art collection in the world using Artificial Intelligence.
