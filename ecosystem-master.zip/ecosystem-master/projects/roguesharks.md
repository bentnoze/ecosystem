---
slug: "gruesomegoblins"
date: "2021-11-1"
title: "Gruesome Goblins"
logline: "An Army, 10,000 strong of the most Gruesome little Goblins invading the Solana blockchain."
cta: "https://www.gruesomegoblins.com"
logo: /img/gruesomegoblins.jpg
category: nft
status: live
website: https://www.gruesomegoblins.com/
twitter: https://twitter.com/GruesomeGoblins
discord: https://discord.com/invite/Goblins
---

An Army, 10,000 strong of the most Gruesome little Goblins invading the Solana blockchain.
