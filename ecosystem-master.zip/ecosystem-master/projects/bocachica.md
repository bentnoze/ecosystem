---
slug: "bocachica"
date: "2021-05-19"
title: "Boca Chica"
logline: "Boca Chica is a collaboration between the HAPI team and Solana to create one of the main IDO platforms on the Solana blockchain."
cta: https://www.bocachica.io/
logo: /img/boca.svg
category: app
status: live
---

HAPI-owned Boca Chica is one of the main facilitators of new Solana-based projects. Boca Chica is creating a fertile soil for new projects on the Solana blockchain that will bolster growth and promote their significance in the crypto sphere.
