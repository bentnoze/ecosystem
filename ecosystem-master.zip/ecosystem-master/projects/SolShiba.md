---
slug: "solshiba"
date: "2021-10-17"
title: "SolShiba"
logline: "SolShiba Is a team of passionate about NFTs and the Solana ecosystem"
cta: "https://solshiba.io"
logo: /img/SolShiba.jpg
category: nft
status: building
website: https://solshiba.io
twitter: https://twitter.com/SolShibaNFTs
discord: https://discord.com/invite/Dk7mr7g2bJ
---

5000 crazy & psycho Shiba wandering on the Solana blockchain waiting for you! 90+ hands drawn traits to generate unique and rare models.
