---
slug: "solstarter"
date: "2020-04-03"
title: "Solstarter"
logline: "Solstarter is the first IDO platform for Solana - empowering launchpad projects to raise liquidity in a fair & decentralized manner."
cta: "https://solstarter.org/"
logo: /img/solstarter.svg
category: app
website: https://solstarter.org/
twitter: https://twitter.com/solstarterorg
telegram: https://t.me/solstarter
status: building
---

Solstarter is the first IDO platform for Solana. It empowers launchpad projects to raise liquidity in a fair & decentralized manner.
