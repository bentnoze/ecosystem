---
slug: steakwallet
date: "2021-08-17"
title: Steakwallet
logline: >-
  Steakwallet is multi chain cryptocurrency staking wallet that supports SOL and
  many other SPL tokens
cta: "https://steakwallet.fi"
logo: /img/steakwallet.svg
category: wallet
status: live
twitter: "https://twitter.com/steakwallet"
---

Steakwallet launched with multi-currency support for three blockchains in mid 2021, adding support for SOL and staking by August.

After collaborating with the Solana team, support for hundreds of SPL tokens is slated to land in September.

<b>Website</b>: https://steakwallet.fi </br>
<b>Twitter</b>: https://twitter.com/steakwallet </br>
<b>Discord</b>: https://steakwallet.fi/chat </br>
