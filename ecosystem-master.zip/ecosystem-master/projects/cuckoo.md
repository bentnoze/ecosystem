---
slug: "cuckoo"
date: "2021-09-29"
title: "Cuckoo"
logline: "Cuckoo is a DEX and NFT marketplace built on Solana"
cta: "https://www.cuckoodex.com/"
category: dex, metaplex, nft
logo: /img/cuckoo.png
website: https://www.cuckoodex.com/
twitter: https://twitter.com/cuckoodex
discord: https://discord.com/invite/GtxjqTxnZG
status: building
---

Cuckoo is an aggregate of a serum based DEX and a Metaplex based NFT marketplace. At Cuckoo, we strongly believe in the Solana ecosystem and its unique capabilities so We hope to combine the fun of NFTs and NFT based terms with a human-centered design and a well organised DEX to make the overall trading experience fun
