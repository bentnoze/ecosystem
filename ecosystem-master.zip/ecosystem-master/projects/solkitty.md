---
slug: "solkitty"
date: "2021-10-04"
title: "SOLKITTY.IO"
logline: "SOLKITTY.IO offers a social network experience with every post being a real genuine NFT powered by the Solana Blockchain"
cta: "https://solkitty.io/"
logo: /img/solkitty.png
category: nft,app
status: live
website: https://solkitty.io/
---

SOLKITTY.IO offers a social network experience with every post being a real genuine NFT powered by the Solana Blockchain. We provide a secure encrypted vault for NFT owners to protect their intellectual property from copyright infringement with our copy cat protection cryptography protocols. Every NFT requires users to provide proof of ownership to verify authenticity. We offer a unique, fun, fast & secure way to mint NFTs, auction NFTs, collect NFTs, connect with your friends and more! Through the power of Solana, minting NFTs are now extremely cheap, fast and secure. No need to pay very high gas fees. Please note: To mint a Public NFT or Social NFT, you will be asked to provide proof of ownership which is integrated through Adobe Sign. Please remember to keep it cool cats, no adult/inappropriate/nude NFTs allowed. Meow!
