---
slug: "boogle"
date: "2021-10-10"
title: "Boogle"
logline: "Boutique NFT project built on Solana 100 total BOOGLEs in gen1."
cta: "https://boogle.holaplex.com/"
logo: /img/boogle.png
category: nft
status: live
website: https://boogle.holaplex.com/
twitter: https://twitter.com/solBOOGLE
discord: https://discord.com/invite/NRa6b4Mhkf
---

Boutique NFT project built on Solana 100 total BOOGLEs in gen1.
