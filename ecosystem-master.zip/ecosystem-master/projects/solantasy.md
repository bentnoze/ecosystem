---
slug: "solantasy"
date: "2021-08-31"
title: "Solantasy"
logline: "Solantasy is a fantasy-themed NFT project featuring three collections. Each collection entails 10,000 algorithmically generated NFTs, with metadata generated using AI."
cta: "https://solantasy.com"
logo: /img/solantasy.png
category: nft
status: building
---

Solantasy is a fantasy-themed NFT project featuring three collections. Each collection entails 10,000 algorithmically generated NFTs, with metadata generated using AI.
