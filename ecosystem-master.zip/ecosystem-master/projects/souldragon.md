---
slug: "souldragons"
date: "2020-09-27"
title: "Soul Dragons"
logline: "The Portal to the Dragon Kingdom is Open. Accept this opportunity for a chance to receive a Unique Soul Dragon Art NFT. Once the mint is complete, all 7777 Soul Dragons will Ascend & continue their Quest into the Metaverse to Enlighten Humanity."
cta: "https://souldragons.com/"
logo: /img/souldragons.png
category: nft
status: live
website: https://souldragons.com/
twitter: https://twitter.com/SoulDragonsBay
discord: https://t.co/z4mcoiO1zq?amp=1
---

The Portal to the Dragon Kingdom is Open. Accept this opportunity for a chance to receive a Unique Soul Dragon Art NFT. Once the mint is complete, all 7777 Soul Dragons will Ascend & continue their Quest into the Metaverse to Enlighten Humanity.
