---
slug: frog
title: FROG
date: 2021-07-15T00:00:00.000Z
logline: >-
  FROG is a project rewards creators, across CT and beyond, for
  their original art and memes.
cta: "https://froglana.com/"
category: NFT
logo: /img/frog.svg
status: Live
website: https://froglana.com/
twitter: https://twitter.com/frogsolana
discord: https://discord.gg/kqJtNkb9C3
---

FROG IS A COMMUNITY MEME TOKEN, BUILT ON SOLANA BLOCKCHAIN.
IT HAS A GREAT USE CASE OF RATING AND IS REWARDING MEME/ART CREATORS.

<b>Website</b>: https://froglana.com/ </br>
<b>Twitter</b>: https://twitter.com/frogsolana </br>
<b>Discord</b>: https://discord.gg/kqJtNkb9C3 </br>
<b>Medium</b>: https://frogsolana.medium.com </br>
