---
slug: "cappuccino"
date: "2021-03-22"
title: "Cappuccino"
logline: "The Cappuccino Stablecoin is pegged to the price of a NY cappuccino."
cta: https://github.com/johnnieskywalker/cappuccino-coffeehouse
logo: /img/cappuccino.svg
category: explorer, DeFi
status: live
---

Cappuccino STABLECOINS are pegged to the price of a cappuccino in NY from Numbeo API. This is a trustless stablecoin which guarantees that you will be able to buy a cappuccino. You can borrow as much Cappuccino as there are cappuccinos in New York minus collateral ratio. When you keep your collateral ratio, you will be able to deposit your Cappuccino into a cup and take back your deposited SOL. So if price of SOL inflates, you will be able to borrow more CAP tokens, or give them back to the cup and receive deposited SOL. If the price of SOL deflates, your deposit will be worth less then your CAP + c-ratio, you won't be able to take back deposited SOL. The program will take it, however you will still be able to enjoy your CAPPUCCINO!
