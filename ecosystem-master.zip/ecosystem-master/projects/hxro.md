---
slug: "hxro"
date: "2020-04-03"
title: "Hxro"
logline: "Hxro is a blockchain-based crypto gaming platform that combines skill-based social media gaming with digital currency trading."
cta: "https://hxro.io/"
logo: /img/hxro.svg
category: defi, exchange
website: https://hxro.io/
twitter: https://twitter.com/RealHxro
telegram: https://t.me/Hxro_Consortium
discord: https://discord.com/invite/kFUTYnm
status: live
---

Hxro is a cryptocurrency platform that offers perpetual, time-based digital derivatives markets. We provide a simplified way to interact with the market, giving traders an alternative way to express a view on price, hedge risk, and trade digital assets. Solana was listed on Hxro in Q1 of 2021.
