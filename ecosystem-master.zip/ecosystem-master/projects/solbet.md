---
slug: solbet
date: "2020-07-27"
title: SOLBET
logline: Trustless P2P Speculation Protocol
cta: "https://solbet.org/"
logo: /img/solbet.svg
category: app
status: building
twitter: "https://twitter.com/solbet_official"
---

SOLBET seeks to facilitate P2P speculation and provide trustless on-chain escrow services for speculative ventures utilizing on-chain data, oracle services and private data node operators to verify outcomes for all parties involved.

Discord: https://discord.gg/Fz4MyrPFJA
Twitter: https://twitter.com/solbet_official
