---
slug: "solstake"
title: "Solstake"
date: 2021-07-25
logline: "Staking SOL should be easy."
category: defi
cta: https://twitter.com/solstakeio
logo: /img/solstake.svg
status: live
website: https://solstake.io
twitter: https://twitter.com/solstakeio
discord: https://discord.com/invite/W8MSvXtfjG
---

Solstake makes staking on Solana easier than ever - no matter what wallet you’re using. Stake your SOL, manage accounts and earn rewards all in a single and easy-to-use app.
