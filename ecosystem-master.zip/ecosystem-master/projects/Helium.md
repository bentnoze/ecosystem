---
slug: "helium"
date: "2014-04-01"
title: "Helium"
logline: "Today, the Helium blockchain, and its tens of thousands of Hotspots, provide access to the largest LoRaWAN Network in the world. Helium released NFTs on one of the first Metaplex storefronts in early June."
cta: "https://www.helium.com/"
logo: /img/helium.svg
category: metaplex, nft
status: live
website: https://metaplex.helium.com/
twitter: https://twitter.com/helium
telegram: https://t.me/helium_network
discord: https://discord.com/invite/helium
---

Helium released Zodiac NFTs on Metaplex in early June of 2021.

Helium is a global, distributed network of Hotspots that create public, long-range wireless coverage for LoRaWAN-enabled IoT devices. Hotspots produce and are compensated in HNT, the native cryptocurrency of the Helium blockchain. The Helium blockchain is a new, open source, public blockchain created entirely to incentivize the creation of physical, decentralized wireless networks.
