---
slug: "nocte"
date: "2020-07-22"
title: "Nocte"
logline: "Nocte is an Automated Market Maker and DEX built on Solana."
cta: "https://nocte.app/"
logo: /img/nocte.svg
category: amm, dex, defi
status: building
website: https://nocte.app/
twitter: https://twitter.com/nocteapp_
discord: https://discord.gg/xtnxJe9zrF
telegram: https://t.me/noctesol
---

Nocte is an Automated Market Maker and DEX built on Solana providing liquidity for SPL tokens and other cross-chain assets, a first for the Solana ecosystem.
