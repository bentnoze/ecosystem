---
slug: "futurefinance"
title: "Future Finance"
date: 2021-07-25
logline: "Fixed rate and swap contracts tokenized on DEX Serum."
category: defi
logo: /img/futurefinance.svg
cta: "https://future-ftr.io/"
status: live
website: https://future-ftr.io/
twitter: https://twitter.com/ftr_finance
telegram: https://t.me/joinchat/5R6McB2bKcA0MTBk
discord: https://discord.com/invite/RdWZsebQfX
---

Future Finance offers fixed rate and swap contracts tokenized on $SOL DEX Serum. Risk management designed to disrupt funding, farming, and yield markets.
