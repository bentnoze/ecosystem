---
slug: "CreepyGirls"
date: "2021-09-09"
title: "Creepy Girl"
logline: "A limited set of 10 000 unique algorithm generated Creepy Girls artworks has over 100 hand-drawn traits which made each of NFT one-of-a-kind. Make sure to have it in your digital collection!"
cta: "https://www.creepygirls.art/"
logo: /img/creepygirls.svg
category: nft, community
website: https://www.creepygirls.art/
twitter: https://twitter.com/CreepyNft
discord: https://discord.gg/47xBFbxJmu
---

A limited set of 10 000 unique algorithm generated Creepy Girls artworks has over 100 hand-drawn traits which made each of NFT one-of-a-kind. Make sure to have it in your digital collection!
