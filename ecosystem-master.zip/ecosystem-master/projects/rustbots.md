---
slug: "rustbots"
date: "2021-10-17"
title: "Rust Bots"
logline: "An advanced NFT collection like you've never seen. Joining all aspects of robot society! The bots of Solana have arrived! Find your RustBot and join the swarm!"
cta: "https://twitter.com/RustBots"
logo: /img/rustbots.png
category: nft
status: building
twitter: https://twitter.com/RustBots
discord: https://discord.com/invite/ZnXWmQjMgu
---

An advanced NFT collection like you've never seen. Joining all aspects of robot society! The bots of Solana have arrived! Find your RustBot and join the swarm!
