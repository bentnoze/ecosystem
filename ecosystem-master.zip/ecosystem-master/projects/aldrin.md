---
slug: "aldrin"
date: "2021-03-18"
title: "Aldrin"
logline: "Aldrin is a CEX and DEX with easy to use advanced tools."
cta: "https://aldrin.com/"
logo: /img/aldrin.svg
category: dex, defi, amm, tools, wallet
status: live
website: https://dex.aldrin.com/
twitter: https://twitter.com/Aldrin_Exchange
telegram: https://t.me/Aldrin_Exchange
discord: https://discord.gg/4VZyNxT2WU
---

Aldrin is a decentralized exchange which mission is to simplify DeFi and create powerful tools to help all traders succeed, leading to more equality.
