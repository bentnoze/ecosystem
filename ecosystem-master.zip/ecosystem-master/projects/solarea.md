---
slug: solarea
date: "2021-07-28"
title: Solarea
logline: >-
  Solarea is a dApps composer and community-driven blockchain
  explorer based on Solana.
cta: "https://solarea.io/"
logo: /img/solarea.svg
category: "explorer, infra"
status: building
twitter: "https://twitter.com/solareaio"
---

Solarea - dApps composer and community-driven blockchain explorer based on Solana.

<b>Website</b>: https://solarea.io </br>
<b>Twitter</b>: https://twitter.com/solareaio </br>
<b>Telegram</b>: https://t.me/solareaio </br>
<b>Discord</b>: https://discord.gg/ZhhhBe3BuW </br>
