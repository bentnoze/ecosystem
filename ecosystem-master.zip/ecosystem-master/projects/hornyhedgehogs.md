---
slug: "hornyhedgehogs"
date: "2021-10-16"
title: "Horny Hedgehogs"
logline: "6969 uniquely generated, horny and collectible hedgehogs with proof of ownership stored on the Solana blockchain. The very first hedgehog-based collectibles in the NFT space!"
cta: "https://www.hornyhedgehogs.com/"
logo: /img/hornyhedge.png
category: nft
status: building
website: https://www.hornyhedgehogs.com/
twitter: https://twitter.com/hornyhedgehogs
discord: https://discord.com/invite/eMBmrQtjNh
---

6969 uniquely generated, horny and collectible hedgehogs with proof of ownership stored on the Solana blockchain. The very first hedgehog-based collectibles in the NFT space!
