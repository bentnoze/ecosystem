---
slug: "angrybunny"
date: "2021-10-14"
title: "Angry Bunny"
logline: "A collection of 5,555 programmatically generated NFT Bunnies on the Solana blockchain."
cta: "https://angrybunny.club/"
logo: /img/angrybunny.png
category: nft
status: live
website: https://angrybunny.club/
twitter: https://twitter.com/AngryBunnyClub
discord: https://discord.com/invite/95hwnRfMWa
---

A collection of 5,555 programmatically generated NFT Bunnies on the Solana blockchain.
