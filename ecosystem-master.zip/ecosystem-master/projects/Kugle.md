---
slug: "kugle"
date: "2021-06-01"
title: "Kugle"
logline: "Cutest 3D game based on Solana chain."
cta: "https://kugle.org/"
logo: /img/Kugle.svg
category: metaplex, nft
status: live
website: https://kugle.org/
twitter: https://twitter.com/kugle_
discord: https://discord.com/invite/uymt9z6rzy
---

Cutest 3D game based on Solana chain. Take part in the decarbonization of the Solana network. Participate in the decarbonization of the Solana blockchain : We will use part of the earnings to plant trees.
