---
slug: "solpad"
date: "2021-05-11"
title: "SolPAD"
logline: "SOLPAD is the first Multichain IDO platform for Solana"
cta: "https://www.solpad.finance/"
category: app
logo: /img/solpad.svg
website: https://www.solpad.finance/
twitter: https://twitter.com/FinanceSolpad
telegram: https://t.me/solpadfinance_chat
status: building
---

SOLPAD is the first Multichain IDO platform for Solana
Enabling projects to raise capital on a decentralized platform, based on Solana.
