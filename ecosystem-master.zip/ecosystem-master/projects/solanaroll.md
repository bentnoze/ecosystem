---
slug: "solanaroll"
date: "2020-04-03"
title: "Solanaroll"
logline: "Solanaroll is a fast, inexpensive dice game with a user-funded pooled treasury. The dice game is provably fair and has a 1% house edge."
category: app
logo: /img/solanaroll.svg
cta: "https://www.solanaroll.com"
status: live
---

Solanaroll is a fast, inexpensive dice game with a user-funded pooled treasury. The dice game is provably fair and has a 1% house edge.
