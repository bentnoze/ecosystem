---
slug: "snowshoe"
title: "Snowshoe"
date: 2021-06-22
logline: "Snowshoe is a community meme token built on Solana."
category: app
logo: /img/snowshoe.svg
status: Live
---

Snowshoe is a project that rewards creators for their original art through a community-ranked leaderboard.

Every week, artists compete in a "CAT ART" event. The top artist will be rewarded in SNOWSHOE tokens and have their art presented on our website.
