---
slug: solstar
date: "2021-07-29"
title: SolStar
logline: Supercharge your community with crypto.
cta: "https://solstar.finance"
logo: /img/solstar.svg
category: "app,amm,defi,spl,tools,wallet,dex,exchange"
status: building
twitter: "https://twitter.com/SolStarFinance"
---

SolStar is a platform for creating and organizing token-powered communities, powered by Solana.

SolStar built an SPL token Discord tip bot, please reach out if you're interested in adding it to your server.

<b>Website</b>: https://solstar.finance</br>
<b>Twitter</b>: https://twitter.com/SolStarFinance </br>
<b>Discord</b>: https://discord.gg/cRUWB474Jb </br>
<b>Medium</b>: https://solstar.medium.com </br>
<b>Telegram</b>: https://t.me/SolStarFinance </br>
