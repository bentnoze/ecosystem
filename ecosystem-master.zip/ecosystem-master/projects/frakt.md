---
slug: "FRAKT"
date: "2021-07-20"
title: "FRAKT"
logline: "Generative art NFT collection on Solana."
cta: https://frakt.art/
logo: /img/frakt.svg
category: nft
status: live
website: https://frakt.art/
twitter: https://twitter.com/FraktArt?s=20
discord: https://discord.com/invite/frakt
telegram: https://t.me/joinchat/-NQJUXugoFlhZDYy
---

FRAKT is the first generative art NFT collection on Solana.
