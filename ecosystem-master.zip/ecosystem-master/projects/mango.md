---
slug: "mango"
date: "2021-03-22"
title: "Mango"
logline: "Mango is a decentralized, cross-margin trading platform with up to 5x leverage with integrated limit orders on Serum DEX’s on-chain order book."
cta: https://mango.markets/
logo: /img/mango.svg
category: DeFi, governance
website: https://mango.markets/
twitter: https://twitter.com/mangomarkets
telegram: https://t.me/mango_markets
discord: https://discord.com/invite/pV5mybZYY8
status: live
---

Mango is a decentralized, cross-margin trading platform with up to 5x leverage with integrated limit orders on Serum DEX’s on-chain order book. Makers or takers can earn interest on deposits and margin positions, as well as trade with near zero fees thanks to Solana’s high-performance blockchain. Additionally, users can contribute SRM into a shared pool, reducing the for all traders on the platform. Congrats, Team Mango!
