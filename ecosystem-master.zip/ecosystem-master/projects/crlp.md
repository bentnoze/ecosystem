---
slug: crlp
date: 2021-03-22
title: Credit Risk Lending Protocol
logline: CRLP is a proof of concept of a cross-chain credit risk and lending protocol for under-collateralized, fixed rate and term loans, without KYC.
cta: https://github.com/sidthekidder/solana-hackathon
logo: /img/crlp.svg
category: DeFi
status: closed
---

POC of a cross-chain credit risk and lending protocol for under-collateralized, fixed rate and term loans, without KYC.
