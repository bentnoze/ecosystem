---
slug: "explorer"
date: "2020-04-03"
title: "Solana Explorer"
logline: "The Solana Explorer allows users to look up transactions and accounts on the various Solana clusters."
cta: "https://explorer.solana.com/"
logo: /img/explorer.svg
category: explorer
status: live
---

The Solana Explorer allows users to look up transactions and accounts on the various Solana clusters.
