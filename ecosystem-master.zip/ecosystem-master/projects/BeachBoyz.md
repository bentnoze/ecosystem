---
slug: "beachboyz"
date: "2021-10-22"
title: "BeachBoyz"
logline: "A lifetime membership to the BeachBoyz Club and a key to unlock the BeachBoyz world, powered by Solana Blockchain!"
cta: "https://BeachBoyz.studio/"
logo: /img/BeachBoyz.png
category: game, nft, metaplex
status: building
website: https://BeachBoyz.studio/
twitter: https://twitter.com/SolBeachBoyz
discord: https://discord.gg/BeachBoyz
---

BeachBoyz is a life-style, a cultural movement, a close-knit community that came together for the passion of living their lives to the fullest.
Project aims to create an open-ended, social simulation, play-to-earn game on the BeachBoyz virtual island. The main objective is to simulate real life situations and activities in a fun and enjoyable manor. BeachBoyz will also be launching as a social ecosystem, dubbed BeachBoyz club, to connect likeminded individuals who shares common interests. Along with its play-to-earn game, allowing the experience sharing and interaction while acting as a membership to its BeachBoyz Resort and their guest free of charge. The funding of such undertaking will be from its NFT launch and continued operation costs be supported by the public, partnerships, as well as NFT royalties.  
