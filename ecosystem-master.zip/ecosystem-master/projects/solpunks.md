---
slug: "solpunks"
title: "SolPunks"
date: 2021-07-25
logline: "Punks on Solana."
category: nft
cta: https://twitter.com/PunksOnSolana
logo: /img/solpunks.svg
status: live
website: https://solpunks.com/
twitter: https://twitter.com/PunksOnSolana
discord: https://discord.com/invite/CJ772sEkGH
---

SolPunks, Punks on Solana, NFTs on the Solana blockchain. Each of these 10,000 SolPunks has attributes that make them unique according to a defined rarity system.
