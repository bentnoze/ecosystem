---
slug: "ren"
title: "Ren"
date: 2021-07-25
logline: "Cross-chain interoperability and liquidity."
category: infra
cta: https://twitter.com/renprotocol
logo: /img/ren.svg
status: live
website: https://renproject.io/
twitter: https://twitter.com/renprotocol
telegram: https://t.me/renproject
---

A secure network of virtual computers that facilitatess interoperability for decentralized applications, enabling cross-chain lending, exchanges, collateralization, and more.
