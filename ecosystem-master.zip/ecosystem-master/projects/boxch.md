---
slug: "boxch"
date: "2021-06-07"
title: "Boxch"
logline: "Boxch - first mobile wallet no fee payer for transaction. Built on Solana."
cta: "https://naxar.ru"
logo: /img/boxch.svg
category: wallet, SPL
status: building
---

Boxch - this is mobile application wallet for android and ios. Token for Boxch it Naxar. You can send Naxar no fee payer.
The team plans to actively develop the application. The first stable version for android is now available in Google Play.
