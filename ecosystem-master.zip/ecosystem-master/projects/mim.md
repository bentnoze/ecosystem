---
slug: "mim"
date: "2021-08-21"
title: "MIM"
logline: "MIM is a swarm for building virtual artists, launching NFTs, and releasing music."
cta: "https://www.mim-swarm.com"
logo: /img/mim.svg
category: nft, metaplex
status: live
---

MIM is a swarm for building virtual artists, launching NFTs, and releasing music. Users can use the MIM token to buy NFT's released by artists, services in the marketplace, or access to unique content.

MIM regularly releases new artists from the swarm. Artists are created by different teams and presented on social media. In addition, MIM is releasing a series of sample packs from the swarm. Each sample pack will contain new material from different artists and producers.
