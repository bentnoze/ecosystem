---
slug: "solati"
date: "2021-07-25"
title: "SOLATI"
logline: "SOLATI is an audible nft project that connects the users and artists through music."
cta: https://solati.io/
logo: /img/solati.svg
category: app, nft
status: building
---

SOLATI project boosts the amateur music market and supports artists to create better work. By owning SOLATI NFT, not only the artwork but also the copyright of the music can be obtained later on. Part of the paid amount goes to the artists.
