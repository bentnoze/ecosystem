---
slug: "sendit"
date: "2020-06-28"
title: "SendIt Finance"
logline: "SendIt is a mobile cross-device portfolio management solution for Solana."
cta: "https://sendit.finance/"
logo: /img/sendit.svg
category: defi, wallet, explorer, app
status: live
website: https://sendit.finance/
twitter: https://twitter.com/sendit_finance
telegram: https://t.me/sendit_finance
discord: https://discord.gg/UcMXyGa7Mm
---

SendIt is a mobile cross-device portfolio viewer and wallet for Solana that prioritizes user experiencr. With a few clicks, view in full your token holdings, farming/staking positions, portfolio history, and much more. Visit [sendit.finance](https://sendit.finance/) today to get started.
