---
slug: "openera"
date: "2021-05-11"
title: "OpenEra"
logline: "OpenEra is a DeFi MMORPG built on Solana and powered by Serum."
cta: "https://twitter.com/OpenEraHQ"
category: app
logo: /img/openera.svg
status: building
twitter: https://twitter.com/OpenEraHQ
discord: http://discord.gg/Tg9dXcnSM4
---

OpenEra is a MMORPG built on the Solana blockchain and powered by Serum. It is inspired by classics like RuneScape and modern MMOs like Albion Online. OpenEra is about uncovering your destiny and taking part in an evolving timeline — traveling through space and time together, as an ever expanding community.
