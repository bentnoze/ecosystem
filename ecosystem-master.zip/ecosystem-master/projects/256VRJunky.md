---
slug: "256VRJunky"
date: "2021-11-06"
title: "256 VRJunky"
logline: "256 VRJunky - a diversity of VR aficionados with the vision of connecting VR and the NFT community. A trading card for adults."
cta: "https://www.cybershoes.com/nft/"
logo: /img/256VRJunky.png
category: nft, game
status: building
website: https://www.cybershoes.com/nft/
twitter: https://twitter.com/CybershoesVR
discord: https://discord.gg/TWnkDnBuEz
---

256 VRJunky - a diversity of VR aficionados with the vision of connecting VR and the NFT community. Being gamers, we like to think of an NFT as a trading card for adults.
The first 128 NFTs to be minted on Nov6th. Other batches of 64, 32, 16, 8, 4, 2, and finally just 1 will NFT launch in the following weeks. The VRJunky-Collection is limited to 256 Non-Fungible-Tokens secured on the Solana blockchain.
The collection is issued by Cybershoes - world's first shoes for walking and running in VR. The Cybershoes Team (VR Shoemakers) has a background in art, media, architecture, and finance. They took the concept for a consumer hardware they envisioned from scratch to market and passed all stages. Prototype – Tradeshows – Kickstarter – Media Hype – Production – Bug Fixes – Game and Platform Integration – Influencer Marketing – Logistics – Listings on Amazons – Fulfillment through Multiple Warehouses – Customer Support. They have completed five crowdfunding campaigns totaling USD 800,000 on various platforms like Kickstarter, Indiegogo, and Conda.
Now Cybershoes are back with VR’s first NFT project: The 256 VRJunky Collection.
