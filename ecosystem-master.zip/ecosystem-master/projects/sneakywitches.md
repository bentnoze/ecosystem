---
slug: "sneakywitches"
date: "2021-10-24"
title: "Sneaky Witches"
logline: "7777 Unique witches taking over the town! More than just an NFT project.."
cta: "https://sneakywitches.com"
logo: /img/sneaky_witches.png
category: nft
status: building
website: https://sneakywitches.com
twitter: https://twitter.com/sneaky_witches
discord: http://discord.gg/sneakywitches
---

7777 Unique witches taking over the town! More than just an NFT project..
