---
slug: "dtfs"
date: "2021-03-22"
title: "DTFs Protocol"
logline: "DTFs Protocol is a Solana and Serum-based system that enables users to implement an asset management strategy in which others can invest."
cta: "https://p2p-org.github.io/Non-custodial-DEX-Traded-Funds/"
logo: /img/dtfs.svg
category: defi
status: building
---

DTFs Protocol is a Solana and Serum-based system that enables users to implement an asset management strategy in which others can invest. A strategy consists of a basket of SPL tokens encapsulated in a DTF program which is itself an SPL token. By supporting external integrations with exchanges, lending platforms, automated market makers, and asset protocols, DTFs enables any type of strategy. DTFs aims to be community-owned and will employ decentralized governance.
