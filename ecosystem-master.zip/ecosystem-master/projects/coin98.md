---
slug: "coin98"
date: "2020-04-03"
title: "Coin98"
logline: "Coin98 is a non-custodial crypto wallet and payments gateway that supports SOL and SPL tokens."
cta: "https://coin98.app/"
logo: /img/coin98.png
category: wallet, SPL
status: live
website: https://coin98.app/
twitter: https://twitter.com/coin98_wallet
telegram: https://t.me/coin98_wallet
---

Coin98 is a non-custodial crypto wallet that provides support for SOL and SPL tokens built on the Solana network. Coin98 also offers payment gateway features and crypto on ramp capabilities.
