---
slug: "jackie"
date: "2021-09-03"
title: "Jackie Chan Fan Token"
logline: "Jackie Chan Fan Token is community driven Crypto"
cta: "https://jackietoken.tk/"
logo: /img/jackie.svg
category: explorer, app, spl
status: live
website: https://jackietoken.tk/
twitter: https://twitter.com/jackie_token/
telegram: https://t.me/jackietoken
---

Jackie Chan Fan Token is community driven crypto. Jackie Token is created because of there fan's love as reward, In future this token will be used as payment on ecommerce website while purchasing Master Jackie Chan related products.
