---
slug: "Pixel Dudes"
date: "2021-06-10"
title: "Pixel Dudes"
logline: "An NFT based Community on Solana."
cta: "https://squidstuff.com"
logo: /img/PDLOGO.png
category: nft, game
status: building
website: https://squidstuff.com
twitter: https://twitter.com/pixeldudesnft
---

Pixel dudes is an NFT store front and community inside the Solana ecosystem that aims to evolve into a game.
