---
slug: "metahomes"
date: "2021-10-06"
title: "Meta Homes"
logline: "Deep into the cyberspace exists metaverse where people own Meta Homes a breakthrough NFT project that reflects your taste in home design."
cta: "https://www.meta-homes.com/"
logo: /img/metahomes.png
category: nft
status: building
website: https://www.meta-homes.com/
twitter: https://twitter.com/MetaHomes
discord: https://discord.com/invite/GhrHmQhXcE
---

Deep into the cyberspace exists metaverse where people own Meta Homes a breakthrough NFT project that reflects your taste in home design.
