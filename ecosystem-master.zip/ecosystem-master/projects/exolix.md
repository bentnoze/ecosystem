---
slug: "exolix"
date: "2020-04-03"
title: "Exolix"
logline: "Exolix is a cryptocurrency exchange that supports the SOL asset."
cta: "https://exolix.com/"
logo: /img/exolix.svg
category: exchange
twitter: https://twitter.com/exolix_com
status: live
---

Exolix is a fast, anonymous, reliable, and fully transparent cryptocurrency exchange that supports SOL.
