---
slug: "Flux"
date: "2021-20-08"
title: "Flux"
logline: "Flux is a cross-chain oracle aggregator that provides smart contracts with access to economically secure data feeds on anything."
cta: "https://fluxprotocol.org"
logo: /img/flux.svg
category: oracle
status: building
website: https://fluxprotocol.org
twitter: https://twitter.com/fluxprotocol
telegram: https://t.me/fluxprotocol
discord: https://discord.com/invite/sJUveAvJHf
---
