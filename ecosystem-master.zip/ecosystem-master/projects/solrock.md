---
slug: "solrock"
date: "2021-08-25"
title: "SolRock NFT"
logline: "Pet Rocks On The Solana
  Blockchain. First and official generation SolRock NFTs on Solana."
cta: "https://solrock.space/"
logo: /img/solrock.svg
category: nft
status: live
website: https://solrock.space/
twitter: https://twitter.com/NFTSolRock
discord: https://t.co/cAP2SbIfGa?amp=1
---

Pet Rocks On The Solana Blockchain. First and official generation SolRock NFTs on Solana.
