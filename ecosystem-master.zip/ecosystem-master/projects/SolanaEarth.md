---
slug: "solanaearth"
date: "2021-10-17"
title: "SolanaEarth"
logline: "A project of 2222 art pieces Ai-drawn"
cta: "https://www.solanaearth.org"
logo: /img/SolanaEarth.png
category: nft
status: Live
website: https://www.solanaearth.org
twitter: https://twitter.com/SolanaEarth
discord: https://discord.com/invite/6pqyyfUQ
---

Sola Earth is a combination of Art, Heritage, Tour and the NFT ecosystem.It's goal is to enhance, develop, preserve and lower the entry to the NFT market.
