---
slug: "liqprotocol"
title: "LIQ Protocol"
date: 2021-06-22
logline: "A decentralized liquidation engine built for Serum DEX margin markets on the Solana network."
cta: "https://liqsolana.com/"
category: dex, defi, spl
logo: /img/liqprotocol.png
status: Live
website: https://liqsolana.com/
twitter: https://twitter.com/liqprotocol
discord: http://discord.gg/liq
telegram: https://t.me/LIQ_channel
---

LIQ Protocol processes liquidations on the Solana chain within the serum ecosystem on platforms offering margin and leverage.
