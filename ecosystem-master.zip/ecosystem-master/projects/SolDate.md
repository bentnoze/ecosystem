---
slug: "soldate"
date: "2021-09-08"
title: "SolDate"
logline: "Make love happen on Blockchain, receive rewards on finding a match"
cta: "https://www.soldate.org"
category: app
logo: /img/soldate.svg
status: building
website: https://www.soldate.org
twitter: https://twitter.com/SolDate_org
telegram: https://t.me/soldate_org
---

Powered by Solana, SolDate is the first decentralized, community-owned dating service. Using a variety of factors, as well as our proprietary framework, we consistently offer personalized, desirable dating matches.
