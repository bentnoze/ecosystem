---
slug: "solchan"
date: "2021-10-09"
title: "Sol Chan"
logline: "A collection of 2050 unique NFT waifus living on Solana blockchain."
cta: "https://solchan.io/"
logo: /img/solchan.png
category: nft
status: live
website: https://solchan.io/
twitter: https://twitter.com/Solchan_NFTurproject
discord: https://discord.com/invite/solchan
---

A collection of 2050 unique NFT waifu living on Solana blockchain.
