---
slug: "solong"
date: "2020-04-03"
title: "Solong"
logline: "Solong is a browser extension that allows users to interact with Solana or Serum applications."
cta: "https://solongwallet.com/"
logo: /img/solong.svg
category: wallet
website: https://solongwallet.com/
twitter: https://twitter.com/Solongwallet
status: live
---

Solong is a slick new extension browser that allows users to interact with any application on Solana or in the Serum ecosystem. It also includes the ability to mint new SPL tokens directly within the UI.
