---
slug: "solpops"
date: "2021-10-10"
title: "Solpops"
logline: "The first NFT Candy Shop on Solana Verified on DigitalEyes and Magic Eden."
cta: "http://solpops.net/index.html"
logo: /img/solpop.png
category: nft
status: live
website: http://solpops.net/
twitter: https://twitter.com/sol_pops
discord: https://discord.com/invite/uUDtr6AHqX
---

The first NFT Candy Shop on Solana Verified on DigitalEyes and Magic Eden.
