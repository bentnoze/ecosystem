---
slug: "metabaes"
date: "2021-10-05"
title: "Metabaes"
logline: "8888 algorithmically generated anime styled characters to take part in our anime episodes."
cta: "https://metabaes.com/"
logo: /img/metabaes.png
category: nft
status: live
website: https://metabaes.com/
twitter: https://twitter.com/MetaBaes
discord: https://discord.com/invite/metabaes
---

Metabaes are created using a large pool of 300+ custom designed characteristics with the ability of producing over 15 MILLION different unique combinations. To say that every Metabae will be unique is an understatement. The art is not all you get when purchasing a Metabae. The utility that a Metabae possesses is even cooler than the art itself . .
