---
slug: "hams"
date: "2021-05-23"
title: "Space Hamster"
logline: "HAMS is a community token built on the Solana blockchain. It has a great use case. The token is fully community driven. So far we have built several ready to use products - Decentralized exchange and NFT Marketplace and plan to develop further.HAMS also has its own unique NFT collection."
cta: https://solhamster.space
logo: /img/hams.png
category: dex, defi, nft, tools, amm
status: live
website: https://solhamster.space
twitter: https://twitter.com/sol_hamster
telegram: https://t.me/SolHamster
discord: https://discord.gg/aqb73zZuDP
gitbook: https://gitbook.solhamster.space
---

HAMS is a community token built on the Solana blockchain. It has a great use case. The token is fully community driven. So far we have built several ready to use products - Decentralized exchange and NFT Marketplace and plan to develop further.HAMS also has its own unique NFT collection.
