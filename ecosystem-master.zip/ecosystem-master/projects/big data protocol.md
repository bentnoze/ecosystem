---
slug: "bigdataprotocol"
title: "Big Data Protocol"
date: 2021-05-28
logline: "Big Data Protocol is DeFi protocol to source commercially valuable data from professional data providers, tokenize it, and make it liquid."
cta: https://twitter.com/bigdataprotocol
category: defi
logo: /img/bigdataprotocol.svg
status: building
---

Big Data Protocol has the following products:

1. Data Vault and Data Room have built tech to tokenize datasets, make data tokens liquid, and redeem the data tokens for the underlying datasets.

2. We’re also working with the Ocean Protocol team to fork Ocean Market. BDP will have full Ocean Market capabilities.
