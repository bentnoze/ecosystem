---
slug: "pixelpenguins"
date: "2021-08-01"
title: "Pixel Penguins"
logline: "The First Official Penguin Project On Solana."
cta: "http://pixelpenguins.holaplex.com/"
logo: /img/Pixel Penguins.svg
category: metaplex, nft
status: live
website: http://pixelpenguins.holaplex.com/
twitter: https://twitter.com/pixeipenguins
discord: https://discord.com/invite/wu8aftbkug
---

Pixel Penguins is the the first official Penguin Project On Solana.
