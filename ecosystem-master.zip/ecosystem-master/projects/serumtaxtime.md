---
slug: "serumtaxtime"
date: "2021-03-22"
title: "SerumTaxTime"
logline: "Serum Tax Time is a trade exporter for the Serum GUI that allows users to download their historical trades into a CSV for tax purposes."
cta: https://github.com/SerumTaxTime
logo: /img/serumtaxtime.svg
category: explorer
status: live
---

Serum Tax Time is a trade exporter for the serum GUI. It allows users to download their historical trades into a CSV for tax purposes.
