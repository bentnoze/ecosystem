---
slug: "solania"
date: "2021-06-19"
title: "Solania"
logline: "Solania is a planetary NFT orbiting the Solana ecosystem."
cta: https://solania.space/
logo: /img/solania.svg
category: nft
status: live
---

Solania is a planetary NFT orbiting the Solana ecosystem.
A wonderful planetary metaverse based on Solana!
