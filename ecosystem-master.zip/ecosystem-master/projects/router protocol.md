---
slug: "routerprotocol"
title: "Router Protocol"
date: 2021-07-25
logline: "Router Protocol is the best crosschain liquidity aggregator and the future of Smart Order Routing."
website: "https://www.routerprotocol.com/"
category: defi
cta: https://twitter.com/routerprotocol
logo: /img/router protocol.svg
status: live
twitter: https://twitter.com/routerprotocol
telegram: https://t.me/routerprotocol
---

Router Protocol developed bridging infrastructure to allow for contract level data flow across various blockchains, thus enabling asset level data transfer.
