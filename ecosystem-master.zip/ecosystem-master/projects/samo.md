---
slug: "samo"
date: "2021-05-11"
title: "Samoyedcoin"
logline: "Samoyedcoin ($SAMO) is Solana’s ambassador."
cta: "https://samoyedcoin.com/"
category: app
logo: /img/samoyedcoin.svg
website: http://samoyedcoin.com/
twitter: https://twitter.com/samoyedcoin
telegram: https://t.me/samoyedcoin
discord: http://discord.gg/caEepqZVcb
status: live
---

Even though it was originally released as a memecoin, SAMO is becoming a real Solana ambassador, introducing Solana to new people, building new and exciting solutions for the ecosystem.

Not only is it the most adorable dog on any blockchain, it also bears the name of one of Solana’s ecosystem most prominent figures: Sam Bankman-Fried, CEO of FTX, making it the perfect Solana doge!

It’s community-owned and fun!
