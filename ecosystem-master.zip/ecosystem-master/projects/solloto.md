---
slug: "sollotto"
date: "2021-07-05"
title: "SolLotto"
logline: "A decentralized lottery platform enabling effective altruism"
cta: "https://sollotto.io/"
logo: /img/sollotto.svg
category: app, defi
status: building
---

A decentralized lottery platform enabling effective altruism
