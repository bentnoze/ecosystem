---
slug: "coolbeans"
date: "2021-10-02"
title: "Cool Beans"
logline: "5000 confused beans who've somehow made their way into the metaverse on Solana."
cta: "https://coolbeans.space/"
logo: /img/coolbeans.png
category: nft
status: live
website: https://coolbeans.space/
twitter: https://twitter.com/CoolBeansNFT
discord: http://discord.gg/3BqazcpXeB
---

5000 confused beans who've somehow made their way into the metaverse. Only on Solana.
