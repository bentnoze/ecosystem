---
slug: "solanatip"
title: "SolanaTip"
date: "2021-08-20"
logline: "Reward content on Twitter with $SOL."
cta: "https://solanatip.io"
category: tools
logo: /img/solanatip.svg
status: live
---

Solanatip is a Chrome extension which allows for Twitter content creators to be rewarded with $SOL. Using Solana's Twitter-specific Name Service, we check if the user to receive the tip has an associated wallet and proceed to make the transaction using the Phantom or Sollet wallet.
