---
slug: "bithumb"
date: "2020-04-03"
title: "Bithumb Global"
logline: "Bithumb Global, one of the premier South Korean crypto exchanges, listed SOL on July 12th, 2020."
cta: "https://www.bithumb.pro/en-us/spot/trade?q=SOL-USDT"
logo: /img/bithumb.svg
category: exchange
status: live
twitter: https://twitter.com/bithumbglobal
---

Bithumb Global (www.bithumb.pro) is an innovative trading platform launched by Bithumb, Korea’s largest digital asset trading platform.
