---
slug: "solaverse"
date: "2021-08-01"
title: "Solaverse"
logline: "A Solana Comic Universe NFT/SFT store."
cta: "https://solaverse.art/#/"
logo: /img/solaverse.svg
category: metaplex, nft
status: live
website: https://solaverse.art/#/
twitter: https://twitter.com/solanacomicmeta
---

Solaverse is a Solana Comic Universe NFT/SFT store built with Metaplex.
