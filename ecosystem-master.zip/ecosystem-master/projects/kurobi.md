---
slug: "kurobi"
date: "2021-06-30"
title: "Kurobi"
logline: "A seamless way for experts to host video calls with guests worldwide."
cta: "https://kurobi.io/"
logo: /img/kurobi.svg
category: app
status: Building
website: https://kurobi.io
twitter: https://twitter.com/kurobi_io
telegram: https://t.me/kurobi_io
---

Why Kurobi?

Kurobi is powered by the Solana blockchain and allows users to host video calls and collect payments in crypto in order to:

- Save time when scheduling
- Make money when hosting
- Earn crypto when booking

Kurobi supports payments with USDT, USDC, SOL, and KURO. $KURO is our native token which is used to:

- Drive mainstream crypto adoption using commission-based cashback incentives
- Support experts via tipping

It's free, seamless, and works on Android phones, iPhones, tablets, and desktops.
