---
slug: "stakeandeggs"
date: "2021-03-22"
title: "Stake and Eggs"
logline: "Stake and Eggs creates Tokenized Stake Pool Shares."
cta: https://github.com/JPCreedon/StakeandEggs/
logo: /img/stake.svg
category: DeFi
status: building
---

Learn more about Tokenized Stake Pool Shares below!
