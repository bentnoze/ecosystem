---
slug: "phant"
date: "2021-10-18"
title: "phant"
logline: "play to earn. make money via crypto"
cta: "www.wecap.io"
logo: /img/phant.png
category: metaplex, game, nft, spl, wallet, dapp
status: building and integration
website: www.wecap.io
twitter: https://twitter.com/wefinph
telegram: https://t.me/wefinc
discord: https://discord.gg/8vsBHQwhTc
---
White Elephant is an ecosystem of crypto products under solana network. Offering Play to Earn, NFT Marketplace, Wallet, DEX on its platform and SPL Token Phant (PNT)
