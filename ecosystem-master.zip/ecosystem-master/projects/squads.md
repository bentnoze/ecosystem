---
slug: "squads"
title: "Squads"
date: 2021-06-22
logline: "One stop shop for all the DAO primitives."
cta: "https://www.buildyoursquad.xyz/"
category: app
logo: /img/squads.svg
status: Building
website: https://www.buildyoursquad.xyz/
twitter: https://twitter.com/squads_dapp
discord: https://t.co/sGN88VVBgy?amp=1
---

Squads will allow users to deploy DAOs on the Solana blockchain.
