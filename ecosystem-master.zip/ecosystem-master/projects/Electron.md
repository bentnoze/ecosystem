---
slug: "electron"
date: "2021-09-05"
title: "Electron"
logline: "Electron is a generalized cross chain messaging protocol that enables Solana Programs to connect with Smart Contracts on all other blockchains"
cta: "https://electronlabs.org/"
logo: /img/Electron-main_resized.png
category: infra, spl
status: building
---

Electron is a generalized cross chain messaging protocol that enables Solana Programs to connect with Smart Contracts on all other blockchains
