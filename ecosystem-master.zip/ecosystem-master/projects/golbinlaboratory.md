---
slug: "goblinlaboratory"
date: "2021-10-14"
title: "Goblin Laboratory"
logline: "The goblin laboratory is upon us. Upload your consciousness to a wetware surrogate and board the ark into hyperspace."
cta: "https://goblinlab.io/#/"
logo: /img/goblin.png
category: nft
status: building
website: https://goblinlab.io/#/
twitter: https://twitter.com/GoblinLabNFT
discord: https://discord.com/invite/12A3bcDE1f
---

The goblin laboratory is upon us. Upload your consciousness to a wetware surrogate and board the ark into hyperspace.
