---
slug: "BalloonBot"
title: "BalloonBot"
date: 2021-07-06
logline: "Solana Telegram Community Transfer Bot, This bot provides an enjoyable experience for users thanks to the incredible speed of the Solana network, in addition to helping more users gain a positive experience in their respective communities."
cta: "https://t.me/balloonrobot"
category: app
logo: /img/balloon.svg
status: Live
---

This bot provides an enjoyable experience for users in their respective communities thanks to the incredible speed of the Solana network

Guide Document: https://www.notion.so/ENG-BalloonBot-Guide-ea629ec744f14e12adb2605c1f63babe
