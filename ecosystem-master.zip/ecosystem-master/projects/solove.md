---
slug: "solove"
date: "2021-10-12"
title: "Solove"
logline: "The collection consists of 8,888 randomly generated SOLOVE locks. This is the final number, no more locks will be available."
cta: "https://solove.io/"
logo: /img/solove.png
category: nft
status: building
website: https://solove.io/
twitter: https://twitter.com/SOLOVENFT
discord: https://discord.com/invite/EDDmkjjus6
---

The collection consists of 8,888 randomly generated SOLOVE locks. This is the final number, no more locks will be available.
