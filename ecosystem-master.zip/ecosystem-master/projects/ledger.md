---
slug: "ledger"
date: "2020-04-03"
title: "Ledger"
logline: "The Ledger Nano X and Nano S support the SOL token."
cta: "https://docs.solana.com/wallet-guide/hardware-wallets"
logo: /img/ledger.svg
category: wallet
website: http://ledger.com/
twitter: https://twitter.com/Ledger
status: live
---

Ledger is a smart way to secure, buy, exchange and grow your crypto assets. The SOL asset is supported on all Ledger devices, including the Nano X and Nano S.
