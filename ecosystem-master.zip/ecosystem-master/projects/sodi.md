---
slug: "sodi"
date: "2021-07-02"
title: "sodi"
logline: "SODI is the currency that powers the SODI social environment system."
cta: "https://www.soldick.xyz/"
logo: /img/sodi.png
category: app
status: building
website: https://www.soldick.xyz/
---

SODI, which powers our social environment, is a utility token that can be used to access our suite of community building features. These features will also be offered to other communities in exchange for project tokens or for burning SODI.
