---
slug: "forgebots"
date: "2021-10-17"
title: "ForgeBots"
logline: "3D generative robots created to live on Solana for eternity. Existing to support STEM/Art non-profits."
cta: "https://twitter.com/forgebots"
logo: /img/forgeboats.png
category: nft
status: building
twitter: https://twitter.com/forgebots
discord: https://discord.com/invite/nZmwCFbtC2
---

3D generative robots created to live on Solana for eternity. Existing to support STEM/Art non-profits.
