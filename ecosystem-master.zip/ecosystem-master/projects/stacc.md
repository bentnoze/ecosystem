---
slug: "stacc"
date: "2021-03-10"
title: "Strategic Tactical RPG"
logline: "Creative and/or Dangerous Blockchain Games."
cta: "https://stacc.art"
logo: /img/stacc.png
category: nft
status: building
website: https://stacc.art/
twitter: https://twitter.com/STACCart
discord: https://discord.gg/WUTFtgDhXd
---

Creative and/or Dangerous Blockchain Games. Mad dev helping redefine the standards that run Solana.
