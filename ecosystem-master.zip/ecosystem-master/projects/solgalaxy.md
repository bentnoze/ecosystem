---
slug: "solgalaxy"
date: "2021-10-22"
title: "SolGalaxy"
logline: "SolGalaxy is a one of a kind collection of 3333 algorithmically generated planets, stars, and other cosmic entities, scattered across the Solana blockchain"
cta: "https://solgalaxy.io"
logo: /img/solgalaxy.jpg
category: nft
status: building
website: https://solgalaxy.io
twitter: https://twitter.com/theSolGalaxy
discord: https://discord.gg/NvYjj9uyaZ
---

SolGalaxy is a one of a kind collection of 3333 algorithmically generated planets, stars, and other cosmic entities, scattered across the Solana blockchain!
