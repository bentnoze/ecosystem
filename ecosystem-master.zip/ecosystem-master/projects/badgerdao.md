---
slug: "badger dao"
date: "2020-9-15"
title: "badger finance"
logline: "Badfer Finance is a community DAO."
cta: "https://badger.finance/"
logo: /img/badger.jpg
category: app, defi
status: building
website: https://badger.finance/
twitter: https://twitter.com/BadgerDAO
discord: https://discord.com/invite/xSPFHHS
---

Badger is a decentralized autonomous organization (DAO) focused on building the products and infrastructure necessary to accelerate the growth of Bitcoin in Decentralized Finance (DeFi) across multiple blockchains.

Badger Finance is a community DAO, focused on bringing Bitcoin to DeFi. The DAO's debut products are Sett, a yield aggregator, and Digg, a BTC-pegged elastic supply currency. The BADGER token is the native governance token for the DAO, granting voting rights over the future direction and use of the treasury.
