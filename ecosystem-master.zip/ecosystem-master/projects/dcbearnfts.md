---
slug: "dcbearnfts"
date: "2021-10-10"
title: "DCBearNFTs"
logline: "DCBearNFTs is an NFT brand housed on the Solana blockchain. The collection consists of 3030 DCBear, 350 first mint, 300 second mint, 2350 last mint."
cta: "https://digitalcustombear.io/"
logo: /img/dcbear.png
category: nft
status: live
website: https://digitalcustombear.io/
twitter: https://twitter.com/DCBearNFTs
discord: https://discord.com/invite/NpmxWSWnHv
---

DCBearNFTs is an NFT brand housed on the Solana blockchain. The collection consists of 3030 DCBear, 350 first mint, 300 second mint, 2350 last mint
