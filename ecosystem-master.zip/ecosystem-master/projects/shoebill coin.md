---
slug: "shoebillcoin"
title: "Shoebill coin"
date: 2021-06-22
logline: "Shoebill Coin is a meme coin designed to turn attention to endangered species, like the Shoebill, and increase exposure to the need for environmental conservation."
cta: "https://shoebillco.in/"
category: app, dex
logo: /img/shoebillcoin.svg
status: Live
website: https://shoebillco.in/
twitter: https://twitter.com/ShoebillCoin
telegram: https://t.co/OSxFlbOX4C?amp=1
discord: https://t.co/TqOjU40spT?amp=1
---

Shoebill Coin is a meme coin designed to turn attention to endangered species, like the Shoebill, and increase exposure to the need for environmental conservation.
