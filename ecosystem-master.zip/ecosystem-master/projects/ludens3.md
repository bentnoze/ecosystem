---
slug: "ludens3"
date: "2021-10-09"
title: "Ludens n3"
logline: "Ludens No.3 is an open-world role-playing game"
cta: "https://ludensno3.com/"
logo: /img/ludens.png
category: nft, game
status: building
website: https://ludensno3.com/
twitter: https://twitter.com/ludensno3
discord: https://discord.com/invite/gM7sYnm8m3
---

Ludens No.3 is an open-world role-playing game
