---
slug: "solbulls"
date: "2021-10-10"
title: "SolBulls Gang"
logline: "A gang of bulls living on #Solana. Breed and merge them to make yours more powerful, then earn money in our play2earn game."
cta: "https://solbulls.art/#/"
logo: /img/solbulls.png
category: nft
status: live
website: https://solbulls.art/#/
twitter: https://twitter.com/SolanaBullsNFT
discord: https://discord.com/invite/Quf39wHSjg
---

A gang of bulls living on #Solana. Breed and merge them to make yours more powerful, then earn money in our play2earn game.
