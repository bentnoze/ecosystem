---
slug: "dassi"
title: "Dassi Finance"
date: "2021-10-05"
logline: "Dassi provides Decentralized peer to peer Banking for Everyone"
cta: https://dassi.finance/
category: defi, fund, app, dapp, nft, stablecoin
logo: /img/dassi.svg
status: Building
website: https://dassi.finance/
twitter: https://twitter.com/DassiFinance
telegram: https://t.me/dassicommunity
discord: https://discord.com/invite/qxr42kBXP8
---

Dassi is a blockchain based crowdfunding platform for zero interest micro-loans and collateral free commercial loans. Our platform is going to be a peer to peer lending platform based on Solana blockchain.

Dassi will also provide users with credit cards with interest rates of around 10% that can be used on websites like Amazon to get emi’s on products like laptops, this will also help us build crypto credit scores of our users.

Dassi will also provide collateral free commercial loans at 12-15% interest rates. For these commercial loans we will have lending pools where people can deposit dassi coins and can get returns of upto 12% .

<b>Website</b>: https://dassi.finance/ </br>
<b>Telegram</b>: https://t.me/dassicommunity </br>
<b>Discord</b>: https://discord.com/invite/qxr42kBXP8 </br>
<b>Twitter</b>: https://twitter.com/DassiFinance </br>
