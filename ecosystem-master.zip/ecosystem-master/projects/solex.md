---
slug: solex-finance
date: "2021-10-20"
title: SOLEX Finance
logline: A DeFi Super-Network Built on Solana
cta: "https://solex.finance/"
logo: /img/solex.png
category: "amm, dex, exchange, tools"
status: building
twitter: "https://solex.finance/"
---

One decentralized and permissionless platform for you to swap, stake, and invest with the low-cost, high efficiency and ultimate experience.

*Website*: https://solex.finance/

*Twitter*: https://twitter.com/SolexFinance
