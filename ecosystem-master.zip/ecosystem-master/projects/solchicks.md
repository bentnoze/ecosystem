---
slug: "solchicks"
date: "2021-09-06"
title: "SolChicks"
logline: "SolChicks allows you to discover rare collectibles and be rewarded for your playtime through a detailed, integrated ecosystem as one of the first NFT-driven gaming platforms built on the Solana blockchain."
cta: "https://solchicks.io/"
logo: /img/solchicks.png
category: nft, metaplex
status: building
---

SolChicks allows you to discover rare collectibles and be rewarded for your playtime through a detailed, integrated ecosystem, all while taking advantage of the power of decentralised ownership that cryptocurrency brings. As one of the first NFT-driven gaming platforms built on the Solana blockchain, SolChicks has combined the best of both worlds into one INTEGRATED gaming platform so now you can enjoy UNIQUE NFT collectibles, and use them as main characters in an exciting virtual world..
