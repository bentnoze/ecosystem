---
slug: "certify"
date: "2020-09-09"
title: "Certify"
logline: "Rapid and scalable blockchain certification platform, built with Solana."
cta: "https://certify.someshkar.com/"
logo: /img/certify.png
category: nft, dapp, tools
status: live
website: https://certify.someshkar.com/
---

Certify is a certification platform that allows the user to simply fill in details into one of our pre-built certificate templates, or design your own from scratch and automatically turns them into on-chain NFTs.
