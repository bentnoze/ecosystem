---
slug: "famousfoxfederation"
date: "2021-10-03"
title: "Famous Fox Federation"
logline: "The Famous Fox Federation is a collection of 7,777 (from over a million combinations) randomly generated and stylistically generated NFTs that exist on the Solana Blockchain."
cta: "https://famousfoxes.com/"
logo: /img/famousfox.png
category: nft
status: live
website: https://famousfoxes.com/
twitter: https://twitter.com/FamousFoxFed
discord: https://discord.gg/S7cPjuXEUu
---

The Famous Fox Federation is a collection of 7,777 (from over a million combinations) randomly generated and stylistically generated NFTs that exist on the Solana Blockchain. The FFF also recognizes all of those less fortunate in the world and as part of our mission we will donate a minimum of 1500 SOL from our proceeds towards causes that the community offers and votes on.

Federation members can participate in exclusive events that will be hosted such as exclusive NFT mints, raffles, community giveaways, and more.
