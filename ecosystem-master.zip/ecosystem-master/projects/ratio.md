---
slug: "ratio"
date: "2021-09-08"
title: "Ratio Finance"
logline: "Ratio Finance is a collateralized debt position (CDP) platform that allows you to leverage your Solana LPs while still gaining yield from farming."
cta: "https://ratio.finance/"
logo: /img/ratio.svg
category: defi, tools
status: building
webpage: https://ratio.finance/
twitter: https://twitter.com/ratiofinance
telegram: https://t.me/ratiofinance
discord: https://discord.gg/5v8AYva8nU
---

Ratio Finance is a collateralized debt position (CDP) platform that allows you to leverage your Solana LPs while still gaining yield from farming.
