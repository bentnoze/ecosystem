---
slug: "solarecofund"
title: "Solar Eco Fund"
date: "2021-05-28"
logline: "Solar Eco Fund is an ecosystem fund dedicated exclusively to Solana and its projects."
cta: "https://www.solarecofund.com/"
twitter: "https://twitter.com/SolarEcoFund"
category: investmentfund
logo: /img/solarecofund.svg
status: live
---

Solar Eco Fund only invests in $SOL, Solana tokens, and companies.
