---
slug: "solanagansta"
date: "2021-10-09"
title: "Solana Gangsta"
logline: "The first ever thumb-drawing art NFTs on Solana , 1234 Generative Art."
cta: "https://solgangsta.com/"
logo: /img/solanagangsta.png
category: nft
status: live
website: https://solgangsta.com/
twitter: https://twitter.com/SolanaGangNFT
discord: https://discord.com/invite/solgangsta
---

The first ever thumb-drawing art NFTs on Solana , 1234 Generative Art.
