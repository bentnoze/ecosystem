---
slug: "solgis-breed-club"
date: "2021-09-04"
title: "Solgis Breed Club"
logline: "Solgis Breed Club is a collection of the 10,000 cutest, randomly generated corgi NFTs on Solana"
cta: "https://twitter.com/Solgis_NFT"
category: nft
logo: /img/solgis.jpg
status: live
Website: https://solgisbreed.club
Twitter: https://twitter.com/Solgis_NFT
Discord: https://discord.com/invite/HXfWH7WC7f
---

The Solgis Breed Club is a community of the 10,000 cutest, randomly generated corgi NFTs on Solana.
