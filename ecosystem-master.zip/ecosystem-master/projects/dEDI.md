---
slug: "dedi"
date: "2021-10-05"
title: "dEDI"
logline: "dEDI is a Web 3.0 on-ramp for legacy EDI users and providers utilizing the Solana blockchain as a transaction layer."
cta: "https://dediinc.com"
logo: /img/dedi.png
category: infra
status: building
website: https://dediinc.com
twitter: https://twitter.com/dedi_inc
discord: https://discord.gg/pmeVXWMF9Z
---

dEDI is a Web 3.0 on-ramp for legacy EDI users and providers utilizing the Solana blockchain as a transaction layer.
