---
slug: "Solatars"
date: "2021-09-22"
title: "Solatars"
logline: "A deflationary NFT collection on the Solana Blockchain that fuses two NFTs to create one rarer."
cta: "https://solatars.com"
logo: /img/solatars.png
category: nft, metaplex
website: https://solatars.com
twitter: https://twitter.com/solatars
discord: http://discord.gg/solatars
status: live
---

Solatars is a deflationary NFT collection on the Solana Blockchain that fuses two NFTs to create one rarer.
