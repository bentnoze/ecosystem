---
slug: "okex"
date: "2020-04-03"
title: "OKEx"
logline: "OKEx, one of the world's leading crypto exchanges, listed SOL on September 30th, 2020."
cta: "https://www.okex.com/"
logo: /img/okex.svg
category: exchange
status: live
---

The SOL token has proven to be a strong addition to the OKEx ecosystem, with trading volume ranked in the top 9 on the exchange. This listing is an exciting new development and we’re delighted Solana will now be traded on one of the largest exchanges in Asia.
