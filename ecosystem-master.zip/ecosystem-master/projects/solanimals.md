---
slug: "solanimals"
date: "2021-07-13"
title: "Solanimals"
logline: "Solanimals are voxel-art NFTs built over Metaplex to buy, trade, and breed. Several attributes are available, and exclusive attributes are obtainable through breeding."
cta: "https://solanimals.com/"
logo: /img/solanimals.svg
category: nft
status: live
---

Solanimals are voxel-art NFT built over Metaplex to buy, trade, and breed. Several attributes are available, and exclusive attributes are obtainable through breeding.
