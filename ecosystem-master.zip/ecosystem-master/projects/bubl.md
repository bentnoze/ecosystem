---
slug: "bubl"
title: "Bubl"
date: 2021-07-25
logline: "Bubl is a decentralized event hosting and ticketing platform built on the Solana blockchain"
category: app
cta: https://www.bublhost.com
logo: /img/bubl.png
status: live
website: https://www.bublhost.com/
twitter: https://twitter.com/bublhost
telegram: http://t.me/bublhost
---

Decentralized event hosting and ticketing. Creating events and buying tickets is now safer and faster.
