---
slug: "popsicle"
date: "2021-04-12"
title: "Popsicle Finance"
logline: "Popsicle finance is a cross-chain yield enhancement platform focusing on Automated Market-Making (AMM) Liquidity Providers (LP)."
cta: "https://popsicle.finance/"
logo: /img/popsicle.svg
category: amm
status: building
webpage: https://popsicle.finance/
twitter: https://twitter.com/popsiclefinance
discord: https://discord.gg/JkEwq5amqw
---

Popsicle finance is a next-gen cross-chain yield enhancement platform focusing on Automated Market-Making (AMM) Liquidity Providers (LP).
