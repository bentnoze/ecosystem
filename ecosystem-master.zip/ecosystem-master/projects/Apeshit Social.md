---
slug: "apeshitsocial"
date: "2021-06-01"
title: "Apeshit Social"
logline: "Apeshit is a charity social club."
cta: "https://apeshit.social/"
logo: /img/apeshit.png
category: metaplex, nft
website: https://apeshit.social/
twitter: https://twitter.com/apeshitsocial
discord: https://discord.com/invite/apeshit
status: live
---

Apeshit is a charity social club built on Solana.
