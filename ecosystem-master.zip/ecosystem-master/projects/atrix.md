---
slug: "atrixProtocol"
date: "2021-10-24"
title: "Atrix Protocol"
logline: "Atrix is the only Serum AMM that allows you to easily create liquidity pools and farms."
cta: "https://www.atrix.finance"
logo: /img/Atrix.jpg
category: amm, defi
status: live
website: https://www.atrix.finance
twitter: https://twitter.com/AtrixProtocol
telegram: https://t.me/AtrixProtocol
discord: https://discord.gg/nfyqSEzUsp
---

Atrix is the only Serum AMM that allows you to easily create liquidity pools and farms.
