---
slug: "magicaland"
date: "2021-10-18"
title: "Magical Land"
logline: "Magical Land is a collection of 5,555 Cute Creatures from 5 different Species.
Get FREE Virtual Land Airdrop and 55% Royalties Goes Back to Community Fund."
cta: "https://magicaland.art/"
logo: /img/magicaland.png
category: nft
status: building
website: https://magicaland.art/
twitter: https://twitter.com/MagiclandNFT
discord: https://discord.gg/magicalandnft
---

Magical Land is a collection of 5,555 Cute Creatures from 5 different Species.
Get FREE Virtual Land Airdrop and 55% Royalties Goes Back to Community Fund.
