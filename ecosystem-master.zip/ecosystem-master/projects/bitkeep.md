---
slug: "bitkeepwallet"
date: "2021-07-25"
title: "BitKeep Wallet"
logline: "BitKeep Wallet is an digital currency wallet and can send and receive SOL/SPL tokens."
cta: "https://bitkeep.org"
category: wallet, SPL
logo: /img/bitkeep.svg
status: live
---

BitKeep Wallet is a mobile wallet that supports SOL. Download it from the iOS or Google Play store to interact with the Solana network on your mobile device.
