---
slug: "springboard"
date: "2021-08-11"
title: "Springboard"
logline: "Springboard is the growth engine for your crypto assets."
cta: "https://springboard.finance/"
logo: /img/springboard.svg
category: defi, governance
twitter: https://twitter.com/springboard_fi
status: building
---

Springboard is a DAO where you can invest into Daults (Decentralised vaults governed by the community) and customised risk strategies to generate DeFi yield. Daults leverage those strategies.
