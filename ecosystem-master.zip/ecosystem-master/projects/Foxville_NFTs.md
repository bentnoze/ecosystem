---
slug: "foxvillenfts"
date: "2021-10-22"
title: "Foxville NFTs"
logline: "First NFTs project Foxville has entered into farm games based on Solana.Play to Earn & Stake your NFTs"
cta: "https://foxville.app"
logo: /img/FoxvilleNFTs.jpg
category: nft
status: building
website: https://foxville.app
twitter: https://twitter.com/foxvilleapp
telegram: https://t.me/Foxvilleapp
discord: http://www.discord.gg/j4d3E98J9m
facebook: https://www.facebook.com/Foxvilleapp-105878458535760
---

First NFTs project Foxville has entered into farm games based on Solana.Play to Earn & Stake your NFTs
