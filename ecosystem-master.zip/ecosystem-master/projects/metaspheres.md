---
slug: "metaspheres"
date: "2021-10-09"
title: "Metaspheres"
logline: "metaSpheres is a procedurally built 3D geometric artwork collection of 986 high quality renders.  Every sphere is unique and are rendered across 18 different looks of varying rarity."
cta: "https://www.metaspheres.xyz/"
logo: /img/metaspheres.png
category: nft
status: live
website: https://www.metaspheres.xyz/
twitter: https://twitter.com/Q_Slerp
discord: https://discord.com/invite/txcEMN6z6m
---

metaSpheres is a procedurally built 3D geometric artwork collection of 986 high quality renders. Every sphere is unique and are rendered across 18 different looks of varying rarity.
