---
slug: "SINR"
title: "SNIR"
date: "2021-09-10"
logline: "SINR is a 1:1 INR pegged stable asset built on the Solana network."
cta: https://cloudflare-ipfs.com/ipfs/QmW963A7i4z3peNL8zVSMVEfwVPWaC7tjKyNcQcBKagZNa/
category: stablecoin
logo: /img/SINR-white.png
status: building
---

SINR brings real-world Indian Rupees to the Solana network. SINR enables users to supply liquidity in DEX and exchange other tokens within the Solana network. These features allow users to easily participate in DeFi, and increases cryptocurrency adoption in Southeast Asia.
