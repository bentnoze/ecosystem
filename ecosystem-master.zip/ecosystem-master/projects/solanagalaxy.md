---
slug: "solanagalaxy"
date: "2021-10-01"
title: "SolanaGalaxy"
logline: "An NFTs and gaming platform in Solana. "
cta: "https://www.solanagalaxy.io/"
logo: /img/solanagalaxy.png
category: nft, game
status: live
website: https://www.solanagalaxy.io/
twitter: https://twitter.com/SolanaGalaxyNFT
discord: https://discord.gg/GKVgZkDnCv
---

There are many galaxies in the universe, but we have focused on just one, and that is the Solana Galaxy, a unique galaxy that is just waiting to be explored.
