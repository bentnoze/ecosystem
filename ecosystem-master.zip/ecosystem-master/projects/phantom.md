---
slug: "phantom"
date: "2020-04-03"
title: "Phantom"
logline: "Phantom is a digital wallet reimagined for Solana and Ethereum."
cta: "https://phantom.app/"
logo: /img/phantom.svg
category: wallet
status: live
website: https://phantom.app/
twitter: https://twitter.com/phantom
---

Phantom is a digital wallet reimagined for DeFi. Phantom makes it safe & easy for you to store, send, receive, collect and swap tokens on the Solana blockchain.
