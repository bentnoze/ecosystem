---
slug: "hedgehog"
date: "2021-03-30"
title: "Hedgehog"
logline: "Hedgehog is a user-centric prediction market platform."
cta: "https://twitter.com/HedgehogMarket"
logo: /img/hedgehog.png
category: defi, amm
status: live
website: https://hedgehog.markets/#/
twitter: https://twitter.com/HedgehogMarket
telegram: https://t.me/hedgehogmarkets
discord: https://discord.gg/vt8Dw5SN58
---

Hedgehog is a lightning-fast prediction market that generates passive yield for LPs while providing users a seamless experience.
