---
slug: "bridgesplit"
date: "2021-02-25"
title: "Bridgesplit"
logline: "Financializing NFTs on Solana"
cta: "https://www.bridgesplit.com"
logo: /img/bridgesplit.png
category: nft
status: building
website: https://www.bridgesplit.com/
twitter: https://twitter.com/bridgesplit
---

Mint and trade fractionalized digital assets
Unlock liquidity and access to unique digital assets: Bridgesplit enables fractionalized ownership of the future.
