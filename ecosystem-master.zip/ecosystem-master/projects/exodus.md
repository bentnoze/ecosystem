---
slug: "exodus"
date: "2020-04-03"
title: "Exodus"
logline: "Exodus is a crypto wallet that supports the SOL asset."
cta: "https://exodus.io"
logo: /img/exodus.svg
category: wallet
status: live
---

Exodus announced support for the SOL token in late 2020. Our product line of desktop, mobile, and hardware crypto wallets all natively support the SOL asset.
