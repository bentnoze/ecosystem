---
slug: "cosmicbloom"
date: "2021-04-01"
title: "Cosmic Bloom"
logline: "Cosmic Bloom is a worldwide healing community."
cta: "https://cosmicbloom.com"
logo: /img/COSMIC BLOOOM.svg
category: metaplex, nft
website: https://cosmicblooom.com/
twitter: https://twitter.com/cosmicblooom
status: live
---

Cosmic Bloom facilitates epic co-creations between artists of various modalities from their community worldwide to inspire humanity with their unique collaborations.
