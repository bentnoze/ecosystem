---
slug: "birdzhouse"
date: "2021-10-09"
title: "Birdzhouse Mansion Club"
logline: "A collection of 333 epic birdzhouse mansions for the toughest Thugbirdz PFP holders. Your birdzhouse provides access to club exclusives."
cta: "https://birdzhousemansionclub.com/"
logo: /img/birdzhouse.png
category: nft
status: live
website: https://birdzhousemansionclub.com/
twitter: https://twitter.com/birdzhouse
discord: https://discord.com/invite/KXXwFaWCKp
---

A collection of 333 epic birdzhouse mansions for the toughest Thugbirdz PFP holders.
Your birdzhouse provides access to club exclusives.
