---
slug: "coinex"
date: "2020-04-03"
title: "CoinEx"
logline: "CoinEx listed the SOL asset in early 2021."
cta: "https://coinex.com"
logo: /img/coinex.svg
category: exchange
status: live
twitter: https://twitter.com/coinexcom
medium: https://coinex.medium.com/
reddit: https://www.reddit.com/r/Coinex/
---

CoinEx is a Chinese based cryptocurrency exchange listed SOL in early 2021.
