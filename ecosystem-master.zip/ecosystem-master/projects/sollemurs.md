---
slug: "sollemurs"
date: "2021-10-10"
title: "Sollemurs"
logline: "Sollemurs are 10,000 algorithmically generated, unique Lemur characters originating from the island of Solasgar and now on the Solana blockchain. Ownership is demonstrable and all commercial rights belong to the holder."
cta: "https://sollemurs.com/#home"
logo: /img/sollemurs.png
category: nft
status: live
website: https://sollemurs.com/
twitter: https://twitter.com/sollemursnft
discord: https://discord.com/invite/yNVNfcUAsJ
---

Sollemurs are 10,000 algorithmically generated, unique Lemur characters originating from the island of Solasgar and now on the Solana blockchain. Ownership is demonstrable and all commercial rights belong to the holder.
