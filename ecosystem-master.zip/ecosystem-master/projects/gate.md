---
slug: "gate"
date: "2020-04-03"
title: "Gate"
logline: "Gate.io listed SOL in the summer of 2020 and currently has multiple SOL spot trading pairs on their exchange."
cta: "http://gate.io/"
logo: /img/gate.svg
category: exchange
status: live
website: http://gate.io/"
twitter: https://twitter.com/gate_io
telegram: https://t.me/gateio
---

Gate.io is a trading platform that does not charge listing fees, launches quality projects, and provides users with a variety of blockchain asset trading services. After winning the listing vote in June of 2020, SOL was listed on the Gate.io exchange.
