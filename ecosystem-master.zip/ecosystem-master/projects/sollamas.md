---
slug: sollamas
date: "2021-08-03"
title: Sollamas
logline: "Algorithmically generated, rare, cute, and collectible NFT Llamas"
cta: "https://sollamas.com/"
logo: /img/sollamas.svg
category: nft
status: building
twitter: "https://twitter.com/SollamasNFT"
---

No two Sollamas will be the same. Each Sollama is generated with attributes based on rarity. From hats, glasses, necklaces, back blankets, beards to even the odd poop. With over 165 unique attributes, it gives a total mathematical combination of millions of unique Sollamas - but with only 10,000 being minted, some are more unique and rare than others.
