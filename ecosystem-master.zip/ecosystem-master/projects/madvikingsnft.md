---
slug: "madvikingsnft"
date: "2021-19-10"
title: "Mad Vikings"
logline: "Warriors of the North | 3D Collection of 10,000 generative NFTs powered by Solana."
cta: "https://twitter.com/madvikingsnft"
logo: /img/madvikings.png
category: nft
status: building
twitter: https://twitter.com/madvikingsnft
discord: https://discord.com/invite/madviking
---

Warriors of the North | 3D Collection of 10,000 generative NFTs powered by Solana.
