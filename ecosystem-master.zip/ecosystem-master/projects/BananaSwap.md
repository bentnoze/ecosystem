---
slug: "bananaswap"
date: "2021-06-04"
title: "BananaSwap"
logline: "Banana Swap is a DEX running on Solana with AMM protocol."
cta: "http://bananaswap.net"
logo: /img/bananaswap.jpeg
category: amm, Defi
status: building
website: http://bananaswap.net
twitter: https://twitter.com/BananaSwap_net
telegram: https://t.me/bananawap_net
discord: https://discord.gg/5SUWdGZffN
Medium: https://bananaswap-net.medium.com/
---

BananaSwap is a decentralized asset trading platform that runs on solana and adopts the AMM mechanism
