---
slug: "infinitylabs"
date: "2021-09-29"
title: "Infinity Labs"
logline: "Collection of 8888 beautiful scenes. 8 different timelines. Collect & merge together timelines to forge new and rarer realities"
cta: "https://infinitylabsnft.com/"
logo: /img/infinitylabs.png
category: nft
status: live
website: https://infinitylabsnft.com/
twitter: https://twitter.com/InfinityLabsNFT
discord: https://t.co/SE7ARmMWCw?amp=1
---

Infinity Labs is a small collective of artists, engineers, ML experts and ex-AAA game devs.
Collection of 8888 beautiful scenes. 8 different timelines. Collect & merge together timelines to forge new and rarer realities
