---
slug: "marinade"
title: "Marinade"
date: 2021-07-25
logline: "The easiest way to stake your tokens. "
category: AMM
cta: "https://marinade.finance/#/"
logo: /img/marinade.svg
status: live
website: https://marinade.finance/#/
twitter: https://twitter.com/MarinadeFinance
discord: https://discord.com/invite/mGqZA5pjRN
---

Marinade.finance is a liquid staking protocol built on Solana. Enjoy automatic reinvestment of rewards and immediate access to tokens with no lockup period.
