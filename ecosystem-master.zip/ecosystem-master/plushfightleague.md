---
slug: "plushfightleague"
date: "2021-10-25"
title: "Plush Fight League"
logline: "PvP fighting  #Game  backed by Solana"
cta: "https://twitter.com/pfl_game"
logo: /img/PlushFightLeague.jpg
category: nft
status: live
twitter: https://twitter.com/pfl_game
telegram: https://t.me/yourproject
discord: https://discord.com/invite/pfl
---

PvP fighting  #Game  backed by Solana
